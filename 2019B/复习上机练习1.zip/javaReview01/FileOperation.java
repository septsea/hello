package javaReview01;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.OutputStreamWriter;

/**
 * FileOperation
 * 
 * 编程题: 使用 FileInputStream、字节字符转换流 (InputStreamReader)、字符缓冲流类对象 (BufferedReader)
 * 读取程序本身, 写到目标文件 (myprogram.txt) 中。提示: Windows 下换行符为 "\r\n"), 并且打印显示在屏幕上。
 */
public class FileOperation {

    public static void main(String... args) throws IOException {
        FileInputStream byteIn = new FileInputStream("./src/javaReview01/FileOperation.java");
        InputStreamReader converter = new InputStreamReader(byteIn);
        BufferedReader buffer = new BufferedReader(converter);
        // 可以用 FileWriter, 但是 FileOutputStream + OutputStreamWriter + BufferedWriter 快很多
        FileOutputStream byteOut = new FileOutputStream("./src/javaReview01/myprogram.txt");
        BufferedWriter output = new BufferedWriter(new OutputStreamWriter(byteOut));
        String temporaryString;
        while (true) {
            temporaryString = buffer.readLine();
            if (temporaryString != null) {
                output.write(temporaryString);
                // 这里可以写 \n, 因为只要能换行就行了, 9102 年的文本编辑器 (包括记事本) 认识 \n
                // Unix (LF) 的换行符是 \n, Windows 的换行符是 \r\n
                // 实在不认识那就写 \r\n
                output.write("\n");
                System.out.println(temporaryString);
            } else {
                break;
            }
        }
        buffer.close();
        output.close();
    }

}
