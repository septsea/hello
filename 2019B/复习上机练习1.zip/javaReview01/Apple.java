package javaReview01;

/**
 * Apple
 * 
 * This is a class extending Fruit.
 */
public class Apple extends Fruit {

    Apple(double weight) {
        super(weight);
    }

    @Override
    double getZongjia() {
        return this.weight * 6;
    }

}
