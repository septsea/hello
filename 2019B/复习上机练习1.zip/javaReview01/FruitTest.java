package javaReview01;

/**
 * FruitTest
 * 
 * This is a class used for testing.
 */
public class FruitTest {

    public static void main(String... args) {
        Apple a = new Apple(4);
        Pear p = new Pear(4, 2);
        System.out.println(a.getZongjia());
        System.out.println(p.getZongjia());
    }

}
