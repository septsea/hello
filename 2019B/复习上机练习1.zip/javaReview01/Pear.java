package javaReview01;

/**
 * Pear
 * 
 * This is a class extending Fruit.
 */
public class Pear extends Fruit {

    double prize;

    Pear(double weight, double prize) {
        super(weight);
        this.prize = prize;
    }

    @Override
    double getZongjia() {
        return this.weight * this.prize;
    }

}
