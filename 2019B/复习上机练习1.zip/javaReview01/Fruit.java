package javaReview01;

/**
 * Fruit
 * 
 * This is the father of Apple and Pear.
 */
public abstract class Fruit {

    double weight;

    Fruit(double weight) {
        this.weight = weight;
    }

    abstract double getZongjia();

}
