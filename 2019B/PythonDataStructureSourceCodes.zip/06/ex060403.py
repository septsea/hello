##################################################################
#文件名：ex060403(6.4.3 Kruskal算法)
#版本号：0.3
#创建时间：2017-12-11
#修改时间：2017-12-18
##################################################################
#算法6-16 Kruskal
##################################################################
#类名称：Vertex
#类说明：定义图的一个顶点
#类释义：包含顶点值data和顶点的相关信息info
##################################################################
class Vertex(object):
    def __init__(self,data):
        self.data = data
        self.info = None
##################################################################
#类名称：Graph
#类说明：定义一个图
#类释义：包含该图的类型kind(0无向图，1无向网，2有向图，3有向网)、
#        顶点集Vertices、邻接矩阵Arcs、图中的顶点数VertexNum和边或弧的数目ArcNum
##################################################################
class Graph(object):
    def __init__(self,kind):
        self.kind = kind
        self.Vertices = []
        self.Arcs = []
        self.ArcNum = 0
        self.VertexNum = 0
    #####################################
    #以邻接矩阵为存储结构创建无向网的方法
    #####################################
    def CreateGraph(self):
        print('请依次输入图中各顶点的值，每个顶点值以回车间隔，并以#作为输入结束符：')
        data = input('->')
        while data is not '#':
            vertex = Vertex(data)
            self.Vertices.append(vertex)
            self.VertexNum = self.VertexNum + 1
            data = input('->')
        self.Arcs = [[0 for i in range(self.VertexNum)] for i in range(self.VertexNum)]
        Horizontal=0
        while Horizontal<self.VertexNum:
            Vertical=0
            while Vertical<self.VertexNum:
                if Vertical is Horizontal:
                    self.Arcs[Horizontal][Vertical]=0
                else:
                    self.Arcs[Horizontal][Vertical]= float("inf")
                Vertical=Vertical+1
            Horizontal=Horizontal+1
        #依次输入边或弧的两个顶点，并进行定位
        print('请依次输入图中每条边的两个顶点值和权值，以空格作为间隔，每输入一组后进行换行，最终以#结束输入：')
        arc = input('->')
        while arc is not '#':
            VertexOne = arc.split()[0]
            VertexTwo = arc.split()[1]
            VertexOneIndex = self.LocateVertex(VertexOne)
            VertexTwoIndex = self.LocateVertex(VertexTwo)
            weight = float(arc.split()[2])
            if self.kind is 1:
                self.Arcs[VertexOneIndex][VertexTwoIndex]=weight
                self.Arcs[VertexTwoIndex][VertexOneIndex]=weight
            self.ArcNum = self.ArcNum + 1
            arc = input('->')
        print('创建成功')        
    ##################################
    #定位顶点在邻接表中的位置的方法
    ##################################
    def LocateVertex(self,Vertex):
        index = 0
        while self.Vertices[index].data != Vertex and index < len(self.Vertices):
            index = index + 1
        return index
    ######################################################
    #将图中的边按权值的升序排列并存储在一个列表中的方法
    ######################################################
    def GetEdges(self,Edges):
        Horizontal=0
        while Horizontal<self.VertexNum:
            Vertical=Horizontal
            while Vertical<self.VertexNum:
                if self.Arcs[Horizontal][Vertical]>0 and self.Arcs[Horizontal][Vertical]<float("inf"):
                    #执行插入操作
                    index = 0
                    flag = True
                    while index<len(Edges) and flag:
                        if Edges[index][2]>self.Arcs[Horizontal][Vertical]:
                            Edges.insert(index,[self.Vertices[Horizontal].data,self.Vertices[Vertical].data,self.Arcs[Horizontal][Vertical]])
                            flag = False
                        index = index + 1
                    if flag:
                        Edges.append([self.Vertices[Horizontal].data,self.Vertices[Vertical].data,self.Arcs[Horizontal][Vertical]])
                Vertical = Vertical + 1
            Horizontal = Horizontal + 1
    #####################################
    #算法6-16 Kruskal 算法
    #####################################
    def MiniSpanTreeKruskal(self,Edges):
        flag=[[]for i in range(self.VertexNum)]
        index = 0
        #初始化顶点标记，其用于判断顶点是否属于同一连通分量
        while index<self.VertexNum:
            flag[index]=index
            index = index + 1
        index=0
        #访问图中的每一条边
        while index<len(Edges):
            VertexOne = self.LocateVertex(Edges[index][0])
            VertexTwo = self.LocateVertex(Edges[index][1])
            #若边的两个顶点不属于同一连通分量，则该边被保留，并将两个顶点划分到同一连通分量内
            if flag[VertexOne] is not flag[VertexTwo]:
                FlagOne = flag[VertexOne]
                FlagTwo = flag[VertexTwo]
                limit=0
                while limit <self.VertexNum:
                    if flag[limit] is FlagTwo:
                        flag[limit] = FlagOne
                    limit = limit+1
                index = index + 1
            else:#否则将该边删除
                Edges.pop(index)

#########
#主程序
#########
if __name__ =='__main__':
    #创建一个连通的无向网
    graph = Graph(1)
    graph.CreateGraph()
    Edges=[]
    graph.GetEdges(Edges)
    #构造最小生成树
    graph.MiniSpanTreeKruskal(Edges)
    print('组成最小生成树的边如下：')
    for item in Edges:
        print(item)
