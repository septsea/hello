##################################################################
#文件名：ex060202(6.2.2 邻接表表示法 算法6-3~算法6-5)
#版本号：0.3
#创建时间：2017-11-8
#修改时间：2017-11-22
#########################################################
#类名称：VertexAdjacencyList
#类说明：定义图的一个顶点
#类释义：包含顶点值data和与该顶点相关联的第一条边FirstArc
#########################################################
#算法6-3 图的顶点的表示
##########################
class VertexAdjacencyList(object):
    def __init__(self,data):
        self.data = data
        self.FirstArc = None
##########################################################
#类名称：AcrAdjacencyList
#类说明：定义图中的一条边或弧
#类释义：包含邻接点或弧头adjacent、与该边或弧相关的信息info和
#        与该边或弧依附于相同顶点的下一条边或弧NextArc
##########################################################
#算法6-4 图的边或弧的表示
##########################
class ArcAdjacencyList(object):
    def __init__(self,adjacent):
        self.adjacent = adjacent
        self.info = None
        self.NextArc = None
##################################################################
#类名称：GraphAdjacencyList
#类说明：定义一个图
#类释义：包含该图的类型kind(0无向图，1无向网，2有向图，3有向网)、
#        图中的顶点数VertexNum、边或弧的数目ArcNum和邻接表Vertices
##################################################################
#算法6-5 图的定义
################################
class GraphAdjacencyList(object):
    def __init__(self,kind):
        self.kind = kind
        self.VertexNum = 0
        self.ArcNum = 0
        self.Vertices = []
