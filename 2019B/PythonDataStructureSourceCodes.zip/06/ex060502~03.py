##################################################################
#文件名：ex060502~03(6.5.2 从某源点到其余各顶点的最短路径 6.5.3 每一对顶点之间的最短路径)
#版本号：0.4
#创建时间：2017-12-12
#修改时间：2017-12-19
##################################################################
#算法6-17~6-18
##################################################################
#类名称：Vertex
#类说明：定义图的一个顶点
#类释义：包含顶点值data和顶点的相关信息info
##################################################################
class Vertex(object):
    def __init__(self,data):
        self.data = data
        self.info = None
##################################################################
#类名称：Graph
#类说明：定义一个图
#类释义：包含该图的类型kind(0无向图，1无向网，2有向图，3有向网)、
#        顶点集Vertices、邻接矩阵Arcs、图中的顶点数VertexNum和边或弧的数目ArcNum
##################################################################
class Graph(object):
    def __init__(self,kind):
        self.kind = kind
        self.Vertices = []
        self.Arcs = []
        self.ArcNum = 0
        self.VertexNum = 0
    ######################################
    #以邻接矩阵为存储结构创建有向网的方法
    ######################################
    def CreateGraph(self):
        print('请依次输入图中各顶点的值，每个顶点值以回车间隔，并以#作为输入结束符：')
        data = input('->')
        while data is not '#':
            vertex = Vertex(data)
            self.Vertices.append(vertex)
            self.VertexNum = self.VertexNum + 1
            data = input('->')
        self.Arcs = [[0 for i in range(self.VertexNum)] for i in range(self.VertexNum)]
        Horizontal=0
        while Horizontal<self.VertexNum:
            Vertical=0
            while Vertical<self.VertexNum:
                if Vertical is Horizontal:
                    self.Arcs[Horizontal][Vertical]=0
                else:
                    self.Arcs[Horizontal][Vertical]= float("inf")
                Vertical=Vertical+1
            Horizontal=Horizontal+1
        #依次输入边或弧的两个顶点，并进行定位
        print('请依次输入图中每条边的两个顶点值和权值，以空格作为间隔，每输入一组后进行换行，最终以#结束输入：')
        arc = input('->')
        while arc is not '#':
            VertexOne = arc.split()[0]
            VertexTwo = arc.split()[1]
            VertexOneIndex = self.LocateVertex(VertexOne)
            VertexTwoIndex = self.LocateVertex(VertexTwo)
            #权值不一定都是整数
            weight = float(arc.split()[2])
            if self.kind is 3:
                self.Arcs[VertexOneIndex][VertexTwoIndex]=weight
            self.ArcNum = self.ArcNum + 1
            arc = input('->')
        print('创建成功')       
    ##################################
    #定位顶点在顶点集中的位置的方法
    ##################################
    def LocateVertex(self,Vertex):
        index = 0
        ######self.Vertices[index].data != Vertex用于判断字符串和数字都行得通
        ######如果用is not只能判断数字，而不能判断字符串
        while self.Vertices[index].data != Vertex and index < len(self.Vertices):
            index = index + 1
        return index
    ###############################
    #算法6-17 Dijkstra 算法
    ###############################
    def Dijkstra(self,Vertex):
        Dist=[[]for i in range(self.VertexNum)]#最短路径长度
        Path=[[]for i in range(self.VertexNum)]#最短路径
        flag=[[]for i in range(self.VertexNum)]#记录顶点是否已求得最短路径
        #初始化三个列表
        index=0
        while index<self.VertexNum:
            Dist[index]=self.Arcs[Vertex][index]
            flag[index]=0
            if self.Arcs[Vertex][index]<float("inf"):
                Path[index]=Vertex
            else:
                Path[index]=-1
            index=index+1
        flag[Vertex]=1
        Path[Vertex]=0
        Dist[Vertex]=0
        index=1
        while index<self.VertexNum:
            MinDist=float("inf")
            j=0#被考察的路径
            #不断选取未被访问的最短的路径
            while j<self.VertexNum:
                if flag[j] is 0 and Dist[j]<MinDist:
                    tVertex=j
                    MinDist=Dist[j]
                j=j+1
            flag[tVertex]=1
            EndVertex=0
            #将MinDist重新置为无穷大
            MinDist=float("inf")
            #更新最短路径长度
            while EndVertex<self.VertexNum:
                if flag[EndVertex] is 0:
                    if self.Arcs[tVertex][EndVertex]<MinDist and Dist[tVertex]+self.Arcs[tVertex][EndVertex]<Dist[EndVertex]:
                        Dist[EndVertex]=Dist[tVertex]+self.Arcs[tVertex][EndVertex]
                        Path[EndVertex]=tVertex
                EndVertex=EndVertex+1
            index=index+1
        self.ShortestPath(Dist,Path,flag,Vertex)
    #################################################
    #输出从顶点Vertex到其他顶点的最短路径(Dijkstra)
    #################################################
    def ShortestPath(self,Dist,Path,flag,Vertex):
        tPath=[]
        index=0
        while index<self.VertexNum:
            if flag[index] is 1 and index is not Vertex:
                print('到达顶点'+self.Vertices[index].data+'的路径为：')
                tPath.append(index)#添加路径终点
                former=Path[index]#获取前一个顶点的下标
                while former is not Vertex:
                    tPath.append(former)
                    former=Path[former]
                tPath.append(Vertex)
                while len(tPath)>0:
                    print(self.Vertices[tPath.pop()].data,end='')
                print()
            index=index+1
    #############################
    #算法6-18 Floyd 算法
    #############################
    def Floyd(self):
        Dist=[[0 for i in range(self.VertexNum)] for i in range(self.VertexNum)]#最短路径长度
        Path=[[0 for i in range(self.VertexNum)] for i in range(self.VertexNum)]#最短路径
        Horizontal=0
        while Horizontal<self.VertexNum:
            Vertical=0
            while Vertical<self.VertexNum:
                Dist[Horizontal][Vertical] = self.Arcs[Horizontal][Vertical]
                if self.Arcs[Horizontal][Vertical]<float("inf") and Horizontal is not Vertical:
                    Path[Horizontal][Vertical]=Horizontal
                else:
                    Path[Horizontal][Vertical]=-1
                Vertical=Vertical+1
            Horizontal=Horizontal+1
        #判断顶点tVertex是否是顶点ArcTail和顶点ArcHead最短路径中的一个顶点
        tVertex=0
        while tVertex<self.VertexNum:
            ArcTail=0
            while ArcTail<self.VertexNum:
                ArcHead=0
                while ArcHead<self.VertexNum:
                    if ArcTail is not ArcHead and (Dist[ArcTail][tVertex]+Dist[tVertex][ArcHead]<Dist[ArcTail][ArcHead]):
                        Dist[ArcTail][ArcHead]=Dist[ArcTail][tVertex]+Dist[tVertex][ArcHead]
                        Path[ArcTail][ArcHead]=Path[tVertex][ArcHead]
                    ArcHead=ArcHead+1
                ArcTail=ArcTail+1
            tVertex=tVertex+1
        self.AllShortestPath(Dist,Path)
    ####################################
    #输出每一组顶点间的最短路径(Floyd)
    ####################################
    def AllShortestPath(self,Dist,Path):
        tPath=[]
        Start=0
        while Start<self.VertexNum:
            End=0
            while End<self.VertexNum:
                if Dist[Start][End]<float("inf") and Start is not End:
                    print('从顶点'+self.Vertices[Start].data+'到顶点'+self.Vertices[End].data+'的路径为：',end='')
                    tVertex=Path[Start][End]
                    tPath.append(End)
                    while (tVertex is not -1) and tVertex is not Start:
                        tPath.append(tVertex)
                        tVertex=Path[Start][tVertex]
                    tPath.append(Start)
                    while len(tPath)>0:
                        print(self.Vertices[tPath.pop()].data,end='')
                    print()
                    print('其路径长度为：'+str(Dist[Start][End]))
                End=End+1
            Start=Start+1
#########
#主程序
#########
if __name__ =='__main__':
    #创建一个有向网
    graph = Graph(3)
    graph.CreateGraph()
    print('构造以下标为0的顶点为起点，网中其余各顶点为终点的最短路径')
    graph.Dijkstra(0)
    print('构造网中各顶点间的最短路径')
    graph.Floyd()
