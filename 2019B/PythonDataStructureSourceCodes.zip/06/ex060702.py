##################################
#文件名：ex060702(6.7.2 求关键路径的算法 算法6-22~6-24)
#版本号：0.2
#创建时间：2017-12-11
#修改时间：2018-1-6
##################################
#######################################################
#类名称：Vertex
#类说明：定义图中的一个顶点
#类释义：包含顶点值data、与该顶点相关联的第一条边FirstArc
#######################################################
class Vertex(object):
    def __init__(self,data):
        self.data = data
        self.FirstArc = None
        self.indegree=0
##########################################################
#类名称：Acr
#类说明：定义图中的一条边
#类释义：包含邻接点adjacent、与该边相关的信息info和
#        与该边依附于相同顶点的另一条边NextArc
##########################################################
class Arc(object):
    def __init__(self,adjacent):
        self.adjacent = adjacent
        self.info = None
        self.NextArc = None
######################################################################
#类名称：GraphSort
#类说明：定义一个图
#类释义：包含该图的类型kind、图中的顶点数VertexNum、边或弧的数目ArcNum
#        、邻接表Vertices、该图的拓扑序列tSort、每一个顶点的最早开
#        始时间EventEarly和最晚开始时间EventLate
######################################################################
#算法6-22 图类的定义
######################
class GraphSort(object):
    def __init__(self,kind):
        self.kind = kind
        self.VertexNum = 0
        self.ArcNum = 0
        self.Vertices = []
        self.tSort = []#存储拓扑序列
        self.EventEarly=[]#每一顶点最早开始时间
        self.EventLate=[]#每一顶点最晚开始时间
    #####################################
    #以邻接表作为存储结构创建有向网的方法
    #####################################
    def CreateGraph(self):
        #依次输入顶点的值，创建顺序存储结构
        print('请依次输入图中各顶点的值，每个顶点值以回车间隔，并以#作为输入结束符：')
        data = input('->')
        while data is not '#':
            vertex = Vertex(data)
            self.Vertices.append(vertex)
            self.VertexNum = self.VertexNum + 1
            data = input('->')
        #依次输入边或弧的两个顶点，并进行定位
        print('请依次输入图中每条边的两个顶点值和权值，以空格作为间隔，每输入一组后进行换行，最终以#结束输入：')
        arc = input('->')
        while arc is not '#':
            TailVertex = arc.split()[0]
            HeadVertex = arc.split()[1]
            weight = arc.split()[2]
            TailIndex = self.LocateVertex(TailVertex)
            HeadIndex = self.LocateVertex(HeadVertex)
            #将与输入的两个顶点相关联的边插入到顶点的链表当中
            self.InsertArc(TailIndex,HeadIndex,weight)
            self.ArcNum = self.ArcNum + 1
            arc = input('->')
        #创建成功
        print('创建成功!')
      
    ##################################
    #定位顶点在顶点集中的位置的方法
    ##################################
    def LocateVertex(self,Vertex):
        index = 0
        ######self.Vertices[index].data != Vertex用于判断字符串和数字都行得通
        ######如果用is not只能判断数字，而不能判断字符串
        while self.Vertices[index].data != Vertex and index < len(self.Vertices):
            index = index + 1
        return index
    ##################################
    #将图中的边或弧插入邻接表的方法
    ##################################
    def InsertArc(self,TailIndex,HeadIndex,weight):
        if self.kind is 3:
            #对TailVertex，插入HeadVertex
            HeadArc = Arc(HeadIndex)
            HeadArc.info = float(weight)
            HeadArc.NextArc = self.Vertices[TailIndex].FirstArc
            self.Vertices[TailIndex].FirstArc = HeadArc
    ##################################
    #得到某一顶点的第一个邻接点的方法
    ##################################
    def GetFirstAdjacentVertex(self,Vertex):
        FirstArc = self.Vertices[Vertex].FirstArc
        if FirstArc is not None:
            return FirstArc.adjacent
        else:
            return None
    #################################################
    #得到某一顶点相对于Adjacent的下一个邻接点的方法
    #################################################
    def GetNextAdjacentVertex(self,Vertex,Adjacent):
        ArcLink = self.Vertices[Vertex].FirstArc
        while ArcLink is not None:
            if ArcLink.adjacent is Adjacent:
                if ArcLink.NextArc is not None:
                    return ArcLink.NextArc.adjacent
                else:
                    return None
            else:
                ArcLink = ArcLink.NextArc
    ########################
    #访问图中某一顶点的方法
    ########################
    def VisitVertex(self,Vertex):
        #print(self.Vertices[Vertex].data)
        self.tSort.append(Vertex)
    #######################
    #统计各顶点入度的方法
    #######################
    def FindIndegree(self):
        index=0
        while index<self.VertexNum:
            tArc = self.Vertices[index].FirstArc
            while tArc is not None:
                self.Vertices[tArc.adjacent].indegree = self.Vertices[tArc.adjacent].indegree + 1
                tArc = tArc.NextArc
            index = index + 1
    ###################################
    #算法6-23 改写后的拓扑排序算法
    ###################################
    def TopologicalSortUpdate(self):
        self.FindIndegree()
        StackVertex=[]
        index=0
        while index<self.VertexNum:
            if self.Vertices[index].indegree is 0:
                StackVertex.append(index)
            self.EventEarly.append(0)
            index = index + 1
        while len(StackVertex)>0:
            tVertex = StackVertex.pop()
            self.VisitVertex(tVertex)
            tAdjacent = self.Vertices[tVertex].FirstArc
            while tAdjacent is not None:
                self.Vertices[tAdjacent.adjacent].indegree = self.Vertices[tAdjacent.adjacent].indegree - 1
                if self.Vertices[tAdjacent.adjacent].indegree is 0:
                    StackVertex.append(tAdjacent.adjacent)
                if (self.EventEarly[tVertex] + tAdjacent.info)>self.EventEarly[tAdjacent.adjacent]:
                    self.EventEarly[tAdjacent.adjacent] = (self.EventEarly[tVertex] + tAdjacent.info)
                tAdjacent = tAdjacent.NextArc
      
    ################
    #关键路径算法
    ################
    def GetCriticalPath(self):
        if len(self.tSort)<self.VertexNum:
            print('该有向网中包含环，因此其没有关键路径，即没有关键活动。。')
            return
        #对邻接表中第tVertex个顶点的最晚开始时间进行初始化
        for item in self.EventEarly:
            self.EventLate.append(item)
        while len(self.tSort)>0:
            tVertex = self.tSort.pop()
            tAdjacent = self.Vertices[tVertex].FirstArc
            if tAdjacent is not None:
                self.EventLate[tVertex] = (self.EventLate[tAdjacent.adjacent]-tAdjacent.info)
            #得到邻接表中第tVertex个顶点的最晚开始时间
            while tAdjacent is not None:
                if (self.EventLate[tAdjacent.adjacent]-tAdjacent.info)<self.EventLate[tVertex]:
                    self.EventLate[tVertex] = (self.EventLate[tAdjacent.adjacent]-tAdjacent.info)
                tAdjacent = tAdjacent.NextArc
        index=0
        while index<self.VertexNum:
            tAdjacent = self.Vertices[index].FirstArc
            while tAdjacent is not None:
                EventEarly = self.EventEarly[index]
                EventLate = self.EventLate[tAdjacent.adjacent]-tAdjacent.info
                if EventEarly == EventLate:
                    print('关键活动：',end='')
                    print(str(self.Vertices[index].data)+':'+str(self.Vertices[tAdjacent.adjacent].data)+'weight:'+str(tAdjacent.info))
                tAdjacent = tAdjacent.NextArc
            index=index+1
       
##############
#主程序
##############
if __name__ =='__main__':
    #创建一个有向网
    graph = GraphSort(3)
    graph.CreateGraph()
    #进行拓扑排序
    graph.TopologicalSortUpdate()
    #构造关键路径
    graph.GetCriticalPath()
