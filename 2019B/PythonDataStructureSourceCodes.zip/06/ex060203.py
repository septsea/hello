###########################################################
#文件名：ex060203(6.2.3 十字链表表示法 算法6-6~算法6-8)
#版本号：0.1
#创建时间：2017-12-16
#修改时间：
###########################################################
###########################################################
#类名称：VertexOrthogonalList
#类说明：定义有向图中的一个顶点
#类释义：包含数据data、以该顶点为弧头的第一条弧FirstHeadArc
#        和以该顶点为弧尾的第一条弧FirstTailArc
###########################################################
#算法6-6 有向图的顶点的表示
####################################
class VertexOrthogonalList(object):
    def __init__(self,data):
        self.data = data
        self.FirstHeadArc = None
        self.FirstTailArc = None
################################################################
#类名称：AcrOrthogonalList
#类说明：定义有向图中的一条弧
#类释义：包含当前弧中弧尾在数组中的下标TailVertex，当前弧中弧头
#        在数组中的下标HeadVertex，与当前弧有相同弧尾的下一条弧
#        NextTailArc，与当前弧有相同弧头的下一条弧NextHeadArc，
#        当前弧包含的其他信息info
################################################################
#算法6-7 有向图的弧的表示
################################
class ArcOrthogonalList(object):
    def __init__(self,TailVertex,HeadVertex):
        self.TailVertex = None
        self.HeadVertex = None
        self.NextTailArc = None
        self.NextHeadArc = None
        self.info =None
####################################################################
#类名称：GraphOrthogonalList
#类说明：定义一个有向图
#类释义：包含图中的顶点数VertexNum、弧的数目ArcNum和十字链表Vertices
####################################################################
#算法6-8 有向图的定义
################################
class GraphOrthogonalList(object):
    def __init__(self,kind):
        self.VertexNum = 0
        self.ArcNum = 0
        self.Vertices = []
