##################################
#文件名：ex060204(6.2.4 邻接多重表表示法 算法6-9~算法6-11)
#版本号：0.1
#创建时间：2017-12-16
#修改时间：
##################################
###########################################################
#类名称：VertexAdjacencyMultitable
#类说明：定义无向图中的一个顶点
#类释义：包含顶点值data、与该顶点相关联的第一条边FirstEdge
###########################################################
#算法6-9 无向图的顶点的表示
################################
class VertexAdjacencyMultitable(object):
    def __init__(self,data):
        self.data = data
        self.FirstEdge = None
################################################################
#类名称：Edge
#类说明：定义无向图中的一条边
#类释义：包含当前边是否被访问的标记mark、该边的两个顶点在数组中
#        的下标VertexOne和VertexTwo、与VertexOne对应的顶点相关联
#        的下一条边NextEdgeOne、与VertexTwo对应的顶点相关联的下
#        一条边、当前边包含的其他信息info
################################################################
#算法6-10 无向图的边的表示
#############################
class Edge(object):
    def __init__(self,VertexOne,VertexTwo):
        self.mark = None
        self.VertexOne = None
        self.NextEdgeOne = None
        self.VertexTwo = None
        self.NextEdgeTwo = None
        self.info =None
########################################################################
#类名称：GraphAdjacencyMultitable
#类说明：定义一个无向图
#类释义：包含图中的顶点数VertexNum、边的数目EdgeNum和邻接多重表Vertices
########################################################################
#算法6-11 无向图的定义
#######################
class GraphAdjacencyMultitable(object):
    def __init__(self,kind):
        self.VertexNum = 0
        self.EdgeNum = 0
        self.Vertices = []
