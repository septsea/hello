##############################################################
#文件名：ex030202.py
#版本号：0.1
#创建时间：2017-09-15
##############################################################
#类名称：CircularSequenceQueue
#类说明：定义一个循环队列
#类释义：提供循环顺序队列的相关操作
##############################################################
class CircularSequenceQueue:
    ############################
    #默认的初始化循环队列的函数
    ############################
    def __init__(self):
        self.MaxQueueSize=4
        self.s=[None for x in range(0,self.MaxQueueSize)]
        self.front=0
        self.rear=0
    ############################
    #初始化循环队列的函数
    ############################
    def InitQueue(self,Max):
        self.MaxQueueSize=Max
        self.s=[None for x in range(0,self.MaxQueueSize)]
        self.front=0
        self.rear=0
    #############################
    #访问某一元素的函数
    #############################        
    def QueueVisit(self,element):
        print(element,end=' ')
    #############################
    #判断循环队列是否为空的函数
    #############################
    def IsEmptyQueue(self):
        if self.front==self.rear:
             iQueue=True
        else:
             iQueue=False
        return iQueue
    #############################
    #元素入队的函数
    #############################
    def EnQueue(self,x):
          if (self.rear+1)%self.MaxQueueSize!=self.front:
              self.rear=(self.rear+1)%self.MaxQueueSize
              self.s[self.rear]=x
          else:
            print("队列已满，无法入队")
            return  
    #############################
    #元素出队的函数
    #############################        
    def DeQueue(self):
        if self.IsEmptyQueue():
           print("队列为空，无法出队")
           return
        else:
            self.front=(self.front+1)%self.MaxQueueSize
            return self.s[self.front]
    #############################
    #依次访问队列中元素的函数
    #############################        
    def QueueTraverse(self):
        if self.IsEmptyQueue():
            print("队列为空，队列无元素可以访问")
            return
        else:
            if  self.front<self.rear:
                i=self.front+1
                while i<self.rear:
                    self.QueueVisit(self.s[i])
                    i=i+1
                self.QueueVisit(self.s[self.rear])
            else:
                i=self.front+1
                while i<self.MaxQueueSize:
                    self.QueueVisit(self.s[i])
                    i=i+1
                i=0
                while i<=self.rear:
                    self.QueueVisit(self.s[i])
                    i=i+1
    #############################
    #获取当前队首元素的函数
    #############################                
    def GetHead(self):
        if self.IsEmptyQueue():
            print("队列为空，无法输出队首元素")
            return
        else:
            return self.s[(self.front+1)%self.MaxQueueSize]
    #############################
    #输出当前队列中元素个数的函数
    #############################    
    def GetQueueLength(self):
        if self.IsEmptyQueue():
            print("队列为空，队列长度为零")
            return
        else:
            return (self.rear-self.front+self.MaxQueueSize)%self.MaxQueueSize
############################
#主程序
############################
'''print("<1>创建一个所有元素均为空（None）的队列。")
qu=CircularSequenceQueue()
print("<2>经判断当前队列",end='')
if qu.IsEmptyQueue()==True:
    print("为空")
else:
    print("不为空")
qu.EnQueue('1')
qu.EnQueue('3')
qu.EnQueue('5')
print("<3>元素",end='')
qu.QueueTraverse()
print("依次进队",end='')
print("\n<4>当前队头元素为",end='')
print(qu.GetHead())
print("<5>当前队列中共有",end='')
print(qu.GetQueueLength(),end='')
print("个元素，分别为",end='')
qu.QueueTraverse()
qu.DeQueue()
print("\n<6>元素1出队，当前队列中元素为",end='')
qu.QueueTraverse()
qu.DeQueue()
print("\n<7>元素3出队，当前队列中元素为",end='')
qu.QueueTraverse()
qu.DeQueue()
print("\n<8>元素5出队，当前",end='')
if qu.IsEmptyQueue()==True:
      print("队列为空")
else:
      print("队列不为空")'''
