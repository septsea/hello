#################################################################
#文件名：ex020202.py
#版本号：0.2
#创建时间：2017-09-27
#修改时间：2018-07-01
#################################################################
#################################################################
#类名称：SequenceList
#类说明：定义一个顺序表
#类释义：创建一个顺序表，并对其执行相关操作。
#################################################################
class SequenceList(object):
    #####################################
    #初始化顺序表函数
    #####################################    
    def __init__(self):
        self.SeqList=[]
    #####################################
    #创建顺序表函数
    #####################################
    def CreateSequenceList(self):        
        print("***************************************************")
        print("*请输入数据后按回车键确认，若想结束输入请按“#”。*")
        print("***************************************************")
        Element=input("请输入元素：")
        while Element!='#':
            self.SeqList.append(int(Element))
            Element=input("请输入元素：")                
    #####################################
    #查找表中某一元素函数
    #####################################
    def FindElement(self):
        key=int(input('请输入想要查找的元素值：'))
        if key in self.SeqList:
            ipos=self.SeqList.index(key)
            print("查找成功！值为",self.SeqList[ipos], "的元素，位于当前顺序表的第",ipos+1,"个位置。")
        else:
            print("查找失败！当前顺序表中不存在值为",key,"的元素")
    #####################################
    #定位插入元素函数
    #####################################
    def InsertElement(self):
        iPos=int(input('请输入待插入元素的位置：'))
        Element=int(input('请输入待插入的元素值：'))
        self.SeqList.insert(iPos,Element)
        print ("插入元素后，当前顺序表为：\n",self.SeqList)
    #####################################
    #删除列表元素函数
    #####################################
    def DeleteElement(self):
        dPos=int(input('请输入待删除元素的位置：'))
        print("正在删除元素",self.SeqList[dPos],"...")
        self.SeqList.remove(self.SeqList[dPos])
        print("删除后顺序表为：\n",self.SeqList)  
    #####################################
    #遍历顺序表函数
    #####################################
    def TraverseElement(self):
        SeqListLen=len(self.SeqList)
        print("******遍历顺序表中元素******")
        for i in range(0,SeqListLen):
            print("第",i+1,"个元素的值为",self.SeqList[i])
            
SeqList = SequenceList()
SeqList.CreateSequenceList()
SeqList.TraverseElement()
SeqList.FindElement()
SeqList.InsertElement()
SeqList.DeleteElement()



