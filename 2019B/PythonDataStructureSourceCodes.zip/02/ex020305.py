#################################################################
#文件名：ex020305.py
#版本号：0.1
#创建时间：2017-10-20
#修改时间：2018-07-01
#带头结点的循环双链表
#################################################################
#################################################################
#类名称：DoubleNode
#类说明：定义一个带头结点的循环双链表的结点
#类释义：分别有指针next和数据data
#################################################################
class DoubleLinkedNode(object):
    #######################
    #初始化结点
    #######################
    def __init__(self,data):
        self.data = data
        self.next = None
        self.prev = None
#################################################################
#类名称：CircularDoubleLinkedList
#类说明：定义一个带头结点的循环双链表
#################################################################		
class CircularDoubleLinkedList(object):
    ####################################
    #初始化头结点
    ####################################
    def __init__(self):
        self.head=DoubleLinkedNode(None)
    ####################################
    #创建循环双链表
    ####################################
    def CreateCircularDoubleLinkedList(self):
        print("**************************************************")
        print("*请输入数据后按回车键确认，若想结束输入请按“#”。*")
        print("***************************************************")
        data=input("请输入元素：")
        cNode=self.head     
        while data!="#":
            nNode=DoubleLinkedNode(int(data))
            cNode.next=nNode
            nNode.prev=cNode
            nNode.next=self.head
            self.head.prev=nNode
            cNode=cNode.next
            data=input("请输入元素：")
    ####################################
    #返回带头结点循环双链表的长度
    ####################################
    def GetLength(self):
        cNode=self.head
        length=0
        while cNode.next!= self.head:
            length=length+1
            cNode=cNode.next
        return length
    ####################################
    #判断带头结点循环双链表是否为空
    ####################################
    def IsEmpty(self):        
        if self.head.next==None:
            return True
        else:
            return False
    ####################################
    #尾端插入元素函数
    ####################################
    def InsertElementInTail(self):
        Element=input("请输入待插入结点的值：")
        if Element=="#":
            return        
        nNode=DoubleLinkedNode(int(Element))
        cNode=self.head
        while cNode.next!=self.head:
            cNode = cNode.next
        cNode.next=nNode
        nNode.prev=cNode
        nNode.next = self.head
        self.head.prev=nNode
    ####################################
    #首端插入元素函数
    ####################################
    def InsertElementInHead(self):
        Element=input("请输入待插入结点的值：")
        if Element=="#":
            return
        cNode=self.head.next
        pNode=self.head
        nNode=DoubleLinkedNode(int(Element))
        nNode.prev=pNode
        pNode.next=nNode
        nNode.next=cNode
        cNode.prev=nNode
    ####################################
    #删除元素函数
    ####################################
    def DeleteElement(self):
        dElement=int(input('请输入待删除结点的值：'))
        cNode=self.head
        pNode=self.head        
        if self.IsEmpty():
            print("当前双链表为空！")
            return
        while cNode.next!=self.head and cNode.data != dElement:
            pNode=cNode
            cNode=cNode.next
        if cNode.data==dElement:
            qNode=cNode.next
            pNode.next=qNode
            qNode.prev=pNode
            del cNode
            print("成功删除含有元素", dElement,"的结点")
        else:
            print("删除失败！双链表中不存在含有元素", dElement,"的结点\n")
    ####################################
    #遍历带头结点循环双链表
    ####################################
    def TraverseElement(self):
        if self.IsEmpty():
            return
        cNode=self.head.next
        print("按next域遍历带头结点双链表:")
        while cNode.next!= self.head:
            print(cNode.data,"->",end="")
            cNode = cNode.next
        print(cNode.data)     
if __name__ == "__main__":
##############################
#创建循环双链表类CDLL
############################## 
    CDLL=CircularDoubleLinkedList()
##############################
#创建循环双链表并遍历
############################## 	
    CDLL.CreateCircularDoubleLinkedList()
    CDLL.TraverseElement()
##############################
#首端插入元素并遍历
##############################
    CDLL.InsertElementInHead()
    CDLL.TraverseElement()
##############################
#尾端插入元素并遍历
##############################    
    CDLL.InsertElementInTail()
    CDLL.TraverseElement()
##############################
#删除元素并遍历
##############################  
    CDLL.DeleteElement()
    CDLL.TraverseElement()
