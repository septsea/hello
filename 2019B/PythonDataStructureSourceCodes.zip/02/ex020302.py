#################################################################
#文件名：ex020302_01.py(ex020302.py)
#版本号：0.3
#创建时间：2017-10-6
#修改时间：2017-10-17
#################################################################

#################################################################
#类名称：Node
#类说明：定义一个结点类
#类释义：创建一个结点类，类中包含数值域与指针域
#################################################################
class Node(object):   
    #####################################
    #初始化结点函数
    ##################################### 
    def __init__(self,data):
        self.data=data
        self.next=None

#################################################################
#类名称：SingleLinkedList
#类说明：定义一个单链表
#类释义：创建一个单链表，并对其执行相关操作
#################################################################
class SingleLinkedList(object):
    #####################################
    #初始化头结点函数
    ##################################### 
    def __init__(self):
        self.head=Node(None)
    #####################################
    #创建单链表函数
    ##################################### 
    def CreateSingleLinkedList(self):
        print("***************************************************")
        print("*请输入数据后按回车键确认，若想结束输入请按“#”。*")
        print("***************************************************")
        cNode=self.head
        Element=input("请输入当前结点的值：")
        while Element!="#":
            nNode=Node(int(Element))
            cNode.next=nNode
            cNode=cNode.next
            Element=input("请输入当前结点的值：")    
    #####################################
    #尾端插入函数
    ##################################### 
    def InsertElementInTail(self):
        Element=(input("请输入待插入结点的值："))
        if Element=="#":
            return
        cNode=self.head
        nNode=Node(int(Element))
        while cNode.next!=None:
            cNode=cNode.next
        cNode.next=nNode
    #####################################
    #首端元素函数
    ##################################### 
    def InsertElementInHead(self):
        Element=input("请输入待插入结点的值：")
        if Element=="#":
            return
        cNode=self.head
        nNode=Node(int(Element))
        nNode.next=cNode.next
        cNode.next=nNode
    #####################################
    #获取单链表长度函数
    ##################################### 
    def GetLength(self):
        cNode=self.head
        length=0
        while cNode.next!=None:
            length=length+1
            cNode=cNode.next
        return length    
    #####################################
    #判断单链表是否为空函数
    ##################################### 
    def IsEmpty(self):
        if self.GetLength()==0:
            return True
        else:
            return False                     
    #####################################
    #查找指定元素并返回其位置函数
    ##################################### 
    def FindElement(self):
        Pos=0
        cNode=self.head
        key=int(input('请输入想要查找的元素值：'))
        if self.IsEmpty():
            print("当前单链表为空！")
            return      
        while cNode.next!=None and cNode.data!=key:
            cNode=cNode.next
            Pos=Pos+1
        if cNode.data==key:
            print("查找成功，值为",key,"的结点位于该单链表的第",Pos,"个位置。")
        else:
            print("查找失败！当前单链表中不存在含有元素",key,"的结点")
    #####################################
    #删除元素函数
    ##################################### 
    def DeleteElement(self):
        dElement=int(input('请输入待删除结点的值：'))
        cNode=self.head
        pNode=self.head
        if self.IsEmpty():
            print("当前单链表为空！")
            return
        while cNode.next!=None and cNode.data != dElement:
            pNode=cNode
            cNode=cNode.next
        if cNode.data==dElement:
            pNode.next=cNode.next
            del cNode
            print("成功删除含有元素", dElement,"的结点")
        else:
            print("删除失败！当前单链表中不存在含有元素", dElement,"的结点")
    #####################################
    #遍历单链表某一结点函数
    ##################################### 
    def VisitElement(self,tNode):
        if tNode!=None:
            print(tNode.data,"->",end="")
        else:
            print("None")
    #####################################
    #遍历单链表函数
    ##################################### 
    def TraverseElement(self):
        cNode=self.head
        if cNode.next==None:
            print("当前单链表为空！")
            return
        print("您当前的单链表为：")
        while cNode!=None:
            cNode=cNode.next
            self.VisitElement(cNode)         
		
##############################
#创建单链表类LinkList
##############################
LinkList=SingleLinkedList()
###############
#创建单链表
###############
LinkList.CreateSingleLinkedList()
###############
#遍历单链表
###############
LinkList.TraverseElement()
###############
#尾端插入元素
###############
LinkList.InsertElementInTail()
###############
#遍历单链表
###############
LinkList.TraverseElement()
###############
#首端插入元素
###############
LinkList.InsertElementInHead()
###############
#遍历单链表
###############
LinkList.TraverseElement()
###############
#查找结点指定位置
###############
LinkList.FindElement()
###############
#删除指定位置结点
###############
LinkList.DeleteElement()
###############
#遍历单链表
###############
LinkList.TraverseElement()



