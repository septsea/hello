#################################################################
#文件名：example2-4.py(ex020306_03.py)
#版本号：0.1
#创建时间：2017-11-17
#【例2-4】
#################################################################
#################################################################
#类名称：DoubleLinkedNode
#类说明：定义一个带头结点的双链表的结点
#类释义：分别有指针next和数据data
#################################################################
class DLNode(object):
    #######################
    #初始化结点
    #######################
    def __init__(self,data):
        self.data=data
        self.next=None
        self.prev=None
#################################################################
#类名称：DoubleLinkedList
#类说明：定义一个带头结点的双链表
#################################################################
class DLL(object):
    ###################################
    #初始化头结点
    ###################################
    def __init__(self):
        self.head=DLNode(None)
    ###################################
    #通过输入数据创建带头结点双链表           
    ###################################
    def CreateDLL(self):
        print("***************************************************")
        print("*请输入数据后按回车键确认，若想结束输入请按“#”。*")
        print("***************************************************")
        data=input("请输入元素：")
        cNode=self.head
        while data!='#':
            nNode=DLNode(int(data))
            cNode.next=nNode
            nNode.prev=cNode
            cNode=cNode.next
            data=input("请输入元素：")    
    ###################################
    #页码翻页函数           
    ###################################
    def PageTurning(self):
        cNode=self.head.next
        print("您当前所在页码为:",cNode.data)
        print("*********************")
        print("*N:向后翻页")
        print("*P:向前翻页")
        print("*Q:退出程序")
        print("*********************")
        order=input("请输入:")
        while order!="Q":
            if order=="N":
                if cNode.next==None:
                    print("您当前位于最后页，无法向后翻页！")
                else:
                    cNode=cNode.next
                    print("您当前所在页码为:",cNode.data)
                order=input("请输入:")
            elif order=="P":
                if cNode.prev==self.head:
                    print("您当前位于第一页，无法向前翻页！")
                else:
                    cNode=cNode.prev
                    print("您当前所在页码为:",cNode.data)
                order=input("请输入:")
            else:
                print("您的输入有误，请重新输入！")
                order=input("请输入:")
    ###################################
    #遍历带头结点双链表
    ###################################
    def TraversDLL(self):
        print("按next域遍历带头结点双链表:")
        cNode=self.head
        while cNode.next!=None:
            cNode=cNode.next            
            print(cNode.data,"->",end="")
        print("None")
if __name__ == "__main__": 
    DLL=DLL()    
    DLL.CreateDLL()
    DLL.PageTurning()
