#################################################################
#文件名：ex020304.py
#版本号：0.1
#创建时间：2017-10-14
#带头结点的双链表
#################################################################
#################################################################
#类名称：DoubleLinkedNode
#类说明：定义一个带头结点的双链表的结点
#类释义：分别有指针next和数据data
#################################################################
class DoubleLinkedNode(object):
    #######################
    #初始化结点
    #######################
    def __init__(self,data):
        self.data=data
        self.next=None
        self.prev=None
#################################################################
#类名称：DoubleLinkedList
#类说明：定义一个带头结点的双链表
#################################################################
class DoubleLinkedList(object):
    ###################################
    #初始化头结点
    ###################################
    def __init__(self):
        self.head=DoubleLinkedNode(None)
    ###################################
    #通过输入数据创建带头结点双链表           
    ###################################
    def CreateDoubleLinkedList(self):
        print("***************************************************")
        print("*请输入数据后按回车键确认，若想结束输入请按“#”。*")
        print("***************************************************")
        data=input("请输入元素：")
        cNode=self.head
        while data!='#':
            nNode=DoubleLinkedNode(int(data))
            cNode.next=nNode
            nNode.prev=cNode
            cNode=cNode.next
            data=input("请输入元素：")
    ###################################
    #获取双链表长度
    ###################################
    def GetLength(self):
        cNode=self.head.next
        length=0
        while cNode!=None:
            length=length+1
            cNode=cNode.next
        return length
    ###################################
    #判断双链表是否为空
    ###################################
    def IsEmpty(self):        
        if self.head.next==None:
            return True
        else:
            return False
    ###################################
    #在带头结点双链表的尾部添加节点
    ###################################
    def InsertElementInTail(self):
        Element=input("请输入待插入结点的值：")
        if Element=="#":
            return
        nNode=DoubleLinkedNode(int(Element))
        cNode=self.head
        while cNode.next!=None:
            cNode=cNode.next           
        cNode.next=nNode
        nNode.prev=cNode
    ###################################
    #在带头结点双链表的头部添加节点
    ###################################
    def InsertElementInHead(self):
        Element=input("请输入待插入结点的值：")
        if Element=="#":
            return
        cNode=self.head.next
        pNode=self.head
        nNode=DoubleLinkedNode(int(Element))
        nNode.prev=pNode 
        pNode.next=nNode           
        nNode.next=cNode
        cNode.prev=nNode                              
    ###################################
    #带头结点双链表中删除指定节点
    ###################################
    def DeleteElement(self):
        dElement=int(input('请输入待删除结点的值：'))
        cNode=self.head
        pNode=self.head        
        if self.IsEmpty():
            print("当前双链表为空！")
            return
        while cNode.next!=None and cNode.data!=dElement:
            pNode=cNode
            cNode=cNode.next
        if cNode.data==dElement:
            if cNode.next==None:
                pNode.next=None
                del cNode
                print("成功删除含有元素", dElement,"的结点！\n")
            else:                
                qNode=cNode.next
                pNode.next=qNode
                qNode.prev=pNode
                del cNode
                print("成功删除含有元素", dElement,"的结点！\n")
        else:
            print("删除失败！双链表中不存在含有元素", dElement,"的结点\n")         
    ###################################
    #遍历带头结点双链表
    ###################################
    def TraversElement(self):
        cNode=self.head
        print("按next域遍历带头结点双链表:")
        if self.IsEmpty():
            print("当前双链表为空！")
            return
        while cNode.next!=None:
            cNode=cNode.next            
            print(cNode.data,"->",end="")
        print("None")           
if __name__ == "__main__":  
##############################
#创建双链表类DLL
############################## 
    DLL=DoubleLinkedList()
##############################
#创建双链表并遍历
############################## 	
    DLL.CreateDoubleLinkedList()
    DLL.TraversElement()   
##############################
#首端插入元素并遍历
##############################	
    DLL.InsertElementInHead()
    DLL.TraversElement()  
##############################
#尾端插入元素并遍历
##############################	
    DLL.InsertElementInTail()
    DLL.TraversElement() 
##############################
#删除元素并遍历
##############################
    DLL.DeleteElement()
    DLL.TraversElement()

