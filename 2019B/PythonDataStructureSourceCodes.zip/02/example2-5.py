#################################################################
#文件名：example2-5.py(ex020305_01.py)
#版本号：0.1
#创建时间：2017-10-20
#修改时间：2018-07-01
#【例2-5】
#################################################################
#################################################################
#类名称：DoubleNode
#类说明：定义一个带头结点的循环双链表的结点
#类释义：分别有指针next和数据data
#################################################################
import operator
import random
class DLNode(object):
    #######################
    #初始化结点
    #######################
    def __init__(self,data):
        self.data=data
        self.next=None
        self.prev=None
#################################################################
#类名称：DoubleCycleLinkedList
#类说明：定义一个带头结点的循环双链表
#################################################################       
class CDLL(object):
    ####################################
    #初始化头结点
    ####################################
    def __init__(self):
        self.head=DLNode(None)
    ####################################
    #创建循环双链表
    ####################################
    def CreateCDLL(self):
        print("*************************************************")
        print("*请输入数据后按回车键确认，若想结束输入请按“#”*")
        print("*************************************************")
        data=input("请输入参与者姓名：")
        cNode=self.head     
        while data!="#":
            nNode=DLNode(data)
            cNode.next=nNode
            nNode.prev=cNode
            nNode.next=self.head
            self.head.prev=nNode
            cNode=cNode.next
            data=input("请输入参与者姓名：")
    ####################################
    #返回带头结点循环双链表的长度
    ####################################
    def GetLength(self):
        cNode=self.head
        length=0
        while cNode.next!= self.head:
            length=length+1
            cNode=cNode.next
        return length
    ###################################
    #查找手持玫瑰者
    ###################################
    def Find(self):
        Pos=0
        cNode=self.head
        cmpResult=False
        name=input('请主持人指定玫瑰当前的持有者：')
        while cNode.next!=self.head and cmpResult==False:
            cNode=cNode.next
            Pos=Pos+1
            cmpResult=operator.eq(cNode.data,name)
        if cmpResult==True:
            return cNode
        else:
            print("输入有误，不存在此参与者。")
    ###################################
    #判断冠亚季军函数
    ###################################
    def JudgeWinner(self,count,tNode):
        if count==1:
            print("此轮比赛的季军是：",tNode.data)
        elif count==2:
            print("此轮比赛的亚军是：",tNode.data)
        elif count==3:
            print("此轮比赛的冠军是：",tNode.data)
        else:
            print("输入有误")
    ###################################
    #传递规则
    ###################################
    def TransRule(self,sign,transNum,count,tNode):
        cNode=tNode
        pNode=cNode.prev
        if sign=="右":
            while transNum!=0:
                cNode=cNode.next
                pNode=pNode.next
                transNum=transNum-1
            if cNode==self.head:
                cNode=cNode.next
                pNode=pNode.next
        elif sign=="左":
            while transNum!=0:
                cNode=cNode.prev
                pNode=pNode.prev
                transNum=transNum-1
            if cNode==self.head:
                cNode=cNode.prev
                pNode=pNode.prev
        else:
            print("输入有误")
        self.JudgeWinner(count,cNode)
        qNode=cNode.next
        pNode.next=qNode
        qNode.prev=pNode
        del cNode
        cNode=pNode.next
    #####################################
    #抽奖函数
    ##################################### 
    def RoseGame(self):
        total=self.GetLength()
        count=1
        while count<4:
            print("*************************************************")
            self.TraverseNode()
            cNode=self.Find()
            pNode=cNode.prev
            print("请",cNode.data,"决定当前传递方向为（左/右）:",end="")
            sign=input()
            randomNum=random.randint(0,100)
            print("主持人第",count,"轮，随机抽取的一个数为（介于1-100）：",randomNum)
            transNum=randomNum%total
            print("传递次数为：",transNum)
            self.TransRule(sign,transNum,count,cNode)
            count=count+1
            total=self.GetLength()
        print("*************************************************")
        print("比赛结束")
    ####################################
    #遍历带头结点循环双链表
    ####################################
    def TraverseNode(self):
        cNode=self.head.next
        print("本轮参与的市民有:")
        while cNode.next!= self.head:
            print(cNode.data,"->",end="")
            cNode = cNode.next
        print(cNode.data)       
if __name__ == "__main__":   
    CDL=CDLL()
    CDL.CreateCDLL()       
    CDL.RoseGame()
