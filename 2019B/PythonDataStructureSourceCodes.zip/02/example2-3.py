#################################################################
#文件名：example2-3.py(ex020306_02.py)
#版本号：0.1
#创建时间：2017-11-16
#【例2-3】
#################################################################
#################################################################
#类名称：Node
#类说明：定义一个带头结点的循环单链表的结点
#类释义：分别有指针next和数据data
#################################################################
class CLNode(object):
    ####################################
    #默认的构造函数，初始化结点
    ####################################       
    def __init__(self,data):
        self.data=data
        self.next=None
#################################################################
#类名称：SingleCircularLinkedList
#类说明：定义一个带头结点的循环单链表
#################################################################		
class CSLL(object):
    ####################################
    #默认的构造函数，初始化头结点
    ####################################          
    def __init__(self):
        self.head=CLNode(None)
    ####################################
    #创建循环单链表
    ####################################       
    def CreateCSLL(self):
        print("***************************************************")
        print("*请输入数据后按回车键确认，若想结束输入请按“#”。*")
        print("***************************************************")
        data=input("请输入参与者姓名：")
        cNode=self.head
        while data!="#":
            nNode=CLNode(data)                 
            cNode.next=nNode
            nNode.next=self.head
            cNode=cNode.next
            data=input("请输入参与者姓名：")
    #####################################
    #获取循环单链表长度函数
    ##################################### 
    def GetLength(self):
        cNode=self.head
        length=0
        while cNode.next!=self.head:
            length=length+1
            cNode=cNode.next
        return length
    ####################################
    #判断循环单链表是否为空
    ####################################       
    def IsEmpty(self):
        if self.GetLength()==0:
            return True
        else:
            return False
    #####################################
    #抽奖函数
    ##################################### 
    def Lottery(self):
        pNode=self.head
        cNode=self.head.next
        count=self.GetLength()
        total=self.GetLength()
        while count!=1:
            import random
            randomNum=random.randint(0,100)
            print("*****************************")
            print("第",(total-count)+1,"轮抽取的随机数为：",randomNum)
            transNum=randomNum%count
            while transNum!=0:
                 pNode=pNode.next
                 cNode=cNode.next 
                 transNum=transNum-1
            if cNode==self.head:
                 cNode=cNode.next
                 pNode=pNode.next
            print("被淘汰的会员为：",cNode.data)
            pNode.next=cNode.next
            del cNode
            cNode=pNode.next
            count=self.GetLength()
        cNode=self.head.next
        print("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$")
        print("最终赢得旅游大奖的是：",cNode.data)
    ####################################
    #遍历当前循环单链表
    ####################################                     
    def TraverseCSLL(self):
        print("当前参与者共有",self.GetLength(),"人,分别为:")
        if self.IsEmpty():
            return
        cNode=self.head.next
        while cNode.next!=self.head:
            print(cNode.data,"->",end="")
            cNode=cNode.next
        print(cNode.data)
if __name__=='__main__':
    CSL=CSLL()
    CSL.CreateCSLL()
    CSL.TraverseCSLL()
    CSL.Lottery()
    
    

       
       
                            
