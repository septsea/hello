#################################################################
#文件名：example2-2.py(ex020306_01.py)
#版本号：0.3
#创建时间：2017-10-6
#修改时间：2017-10-17
#【例2-2】
#################################################################
#################################################################
#类名称：Node
#类说明：定义一个结点类
#类释义：创建一个结点类，类中包含数值域与指针域
#################################################################
class StudentNode(object):   
    #####################################
    #初始化结点函数
    ##################################### 
    def __init__(self,name,sex):
        self.name=name
        self.sex=sex
        self.next=None      
#################################################################
#类名称：SingleLinkedList
#类说明：定义一个单链表
#类释义：创建一个单链表，并对其执行相关操作
#################################################################
class SLL(object):
    #####################################
    #初始化头结点函数
    ##################################### 
    def __init__(self):
        self.head=StudentNode(None,None)
    #####################################
    #创建单链表函数
    ##################################### 
    def CreateStudentSLL(self):
        print("***************************************************")
        print("*请输入数据后按回车键确认，若想结束输入请按“#”。*")
        print("***************************************************")
        cNode=self.head
        Element=input("请输入姓名,性别并用空格隔开:")
        while Element!="#":
            Name=Element.split(" ")[0]
            Sex=Element.split(" ")[1]
            nNode=StudentNode(Name,Sex)
            cNode.next=nNode
            cNode=cNode.next
            Element=input("请输入姓名,性别并用空格隔开:")
    #####################################
    #获取单链表长度函数
    ##################################### 
    def GetLength(self):
        cNode=self.head
        length=0
        while cNode.next!=None:
            length=length+1
            cNode=cNode.next
        return length 
    #####################################
    #拆分单链表函数
    ##################################### 
    def DivideSLL(self,LinkedListB,LinkedListC):
        aNode=self.head
        bNode=LinkedListB.head
        cNode=LinkedListC.head
        cPos=0
        while aNode.next!=None:
            aNode=aNode.next
            cPos=cPos+1
            pNode=aNode
            if cPos%2==1:
                bNode.next=pNode
                bNode=bNode.next
            else:
                cNode.next=pNode
                cNode=cNode.next
        bNode.next=None
        cNode.next=None
    #####################################
    #遍历单链表函数
    ##################################### 
    def TraverseSLL(self):
        cNode=self.head.next
        while cNode.next!=None:
            print(cNode.name,"->",end="")
            cNode=cNode.next
        print(cNode.name)
    #####################################
    #打印函数
    ##################################### 
    def PrintSLL(self):
        cNode=self.head.next
        if cNode.sex=="男":
            print("**********************************")
            print("男生小分队包含",self.GetLength(),"个人,分别是:")
            self.TraverseSLL()
        else:
            print("**********************************")
            print("女生小分队包含",self.GetLength(),"个人,分别是:")
            self.TraverseSLL()
        print("**********************************")
if __name__=='__main__':
    LA=SLL()
    LB=SLL()
    LC=SLL()
    LA.CreateStudentSLL()
    LA.DivideSLL(LB,LC)
    LB.PrintSLL()
    LC.PrintSLL()
