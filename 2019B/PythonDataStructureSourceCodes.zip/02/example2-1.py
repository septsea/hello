#################################################################
#文件名：example2-1.py（ex020303.py）
#版本号：0.1
#创建时间：2017-10-31
#【例2-1】
#################################################################

#################################################################
#类名称：Node
#类说明：定义一个带头结点的循环单链表的结点
#类释义：分别有指针next和数据data
#################################################################
class Node(object):
    ####################################
    #默认的构造函数，初始化结点
    ####################################       
    def __init__(self,data):
        self.data=data
        self.next=None
#################################################################
#类名称：CircularSingleLinkedList
#类说明：定义一个带头结点的循环单链表
#################################################################		
class CircularSingleLinkedList(object):
    ####################################
    #默认的构造函数，初始化头结点
    ####################################          
    def __init__(self):
        self.head=Node(None)
    ####################################
    #创建循环单链表
    ####################################       
    def CreateCircularSingleLinkedList(self):
        print("***************************************************")
        print("*请输入数据后按回车键确认，若想结束输入请按“#”。*")
        print("***************************************************")
        cNode=self.head
        data=input("请输入结点的值：")
        while data!="#":
            nNode=Node(int(data))
            cNode.next=nNode
            nNode.next=self.head
            cNode=cNode.next
            data=input("请输入结点的值：")
    #####################################
    #获取单链表长度函数
    ##################################### 
    def GetLength(self):
        cNode=self.head
        length=0
        while cNode.next!=self.head:
            length=length+1
            cNode=cNode.next
        return length       
    ####################################
    #判断循环单链表是否为空
    ####################################       
    def IsEmpty(self):
        if self.GetLength()==0:
            return True
        else:
            return False
    #####################################
    #尾端插入函数
    ##################################### 
    def InsertElementInTail(self):
        Element=input("请输入待插入结点的值：")
        if Element=="#":
            return
        cNode=self.head
        nNode=Node(int(Element))
        while cNode.next!=self.head:
            cNode=cNode.next
        cNode.next=nNode
        nNode.next=self.head                     
    #####################################
    #首端插入函数
    ##################################### 
    def InsertElementInHead(self):
        Element=input("请输入待插入结点的值：")
        if Element=="#":
            return
        cNode=self.head
        nNode=Node(int(Element))
        nNode.next=cNode.next
        cNode.next=nNode                  
    #####################################
    #删除元素函数
    ##################################### 
    def DeleteElement(self):
        dElement=int(input('请输入待删除结点的值：'))
        cNode=self.head
        pNode=self.head
        if self.IsEmpty():
            print("当前单链表为空！")
            return
        while cNode.next!=self.head and cNode.data != dElement:
            pNode=cNode
            cNode=cNode.next
        if cNode.data==dElement:
            pNode.next=cNode.next
            del cNode
            print("成功删除含有元素", dElement,"的结点")
        else:
            print("删除失败!双链表中不存在含有元素", dElement,"的结点")
    ####################################
    #遍历当前循环单链表
    ####################################                     
    def TraversElement(self):
        if self.IsEmpty():
            print("当前循环单链表为空！")
            return
        cNode=self.head.next
        print("您当前的循环单链表为：")
        while cNode.next!=self.head:
            print(cNode.data,"->",end="")
            cNode=cNode.next
        print(cNode.data)
if __name__=='__main__':
##############################
#创建循环单链表类scl
##############################
    scl=SingleCircularLinkedList()
##############################
#创建循环单链表
##############################
    scl.CreateSingleCircularLinkedList()
##############################
#尾端插入元素
##############################
    scl.InsertElementInTail()
##############################
#遍历循环单链表
##############################
    scl.TraversElement()
##############################
#首端插入元素
##############################
    scl.InsertElementInHead()
##############################
#遍历循环单链表
##############################
    scl.TraversElement()
##############################
#删除元素
##############################
    scl.DeleteElement()
##############################
#遍历循环单链表
##############################
    scl.TraversElement()

       
       
                            
