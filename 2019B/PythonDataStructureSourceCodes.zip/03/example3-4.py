#######################################################################
#文件名：example3-4.py
#版本号：0.1
#创建时间：2017-09-14
#修改时间：2018-07-01
##############################################################
#类名称：CircularSequenceQueue
#类说明：定义一个循环队列
#类释义：提供循环顺序队列的相关操作
##############################################################
class CircularSequenceQueue:
    ############################
    #默认的初始化循环队列的函数
    ############################
    def __init__(self):
        self.MaxQueueSize=10
        self.s=[None for x in range(0,self.MaxQueueSize)]
        self.front=0
        self.rear=0
    #############################
    #判断队列是否为空的函数
    #############################
    def IsEmptyQueue(self):
        if self.front==self.rear:
             iQueue=True
        else:
             iQueue=False
        return iQueue
    #############################
    #元素入队的函数
    #############################    
    def EnQueue(self,x):
        if (self.rear+1)%self.MaxQueueSize!=self.front:
              self.rear=(self.rear+1)%self.MaxQueueSize
              self.s[self.rear]=x
        else:
            print("队列已满，无法入队")
            return  
    #############################
    #元素出队的函数
    #############################        
    def DeQueue(self):
        if self.IsEmptyQueue():
           print("队列为空，无法出队")
           return
        else:
            self.front=(self.front+1)%self.MaxQueueSize
            return self.s[self.front]
    #############################
    #获取当前队首元素的函数
    #############################  
    def GetHead(self):
        if self.IsEmptyQueue():
            print("队列为空，无法输出队首元素")
            return
        else:
            return self.s[(self.front+1)%self.MaxQueueSize]
    #############################
    #获取当前队列长度的函数
    #############################    
    def GetQueueLength(self):
        if self.IsEmptyQueue():
            print("队列为空，队列长度为零")
            return
        else:
            return (self.rear-self.front+self.MaxQueueSize)%self.MaxQueueSize
##############################################################
#类名称：TestFN
#类说明：兔子繁殖问题
#类释义：计算指定月份的兔子总数，以及对计算正确性的测试
##############################################################       
class TestFN:
    ###############################
    #输出指定月份小兔总对数的函数
    ###############################
    def Fibonacci(self,n):
        qu=CircularSequenceQueue()
        if n==0:
            print("一开始小兔的总对数为:",1)
            return
        if n==1:
            print("第",n,"个月小兔的总对数为:",2)
            return
        else:
            qu.EnQueue(1)
            qu.EnQueue(2)
            iMonth=1
            while iMonth<n:
                NumHead=qu.DeQueue()
                NumRear=qu.GetHead()
                TotalNumber=NumHead+NumRear
                qu.EnQueue(TotalNumber)                
                iMonth=iMonth+1
            while qu.GetQueueLength()!=1:
                qu.DeQueue()
            print("第",n,"个月小兔的总对数为:",qu.DeQueue())
    ###########################################
    #测试指定月份小兔总对数的函数的正确性的函数
    ###########################################
    def TestFibonacci(self):
        n=int(input("请输入需要求哪个月的小兔总数："))
        while n<0:
            n=int(input("请重新输入需要求哪个月的小兔总数："))
        self.Fibonacci(n)            
#############################################
#测试输出指定月份小兔总对数函数的正确性的函数
#############################################
TFN=TestFN()
TFN.TestFibonacci()

      
