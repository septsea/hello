#######################################################################
#文件名：example3-1.py
#版本号：0.1
#创建时间：2017-09-14
#修改时间：2018-07-01
#######################################################################
#类名称：SequenceStack
#类说明：定义一个栈
#类释义：提供顺序栈的相关操作
#######################################################################
class SequenceStack:
    ############################
    #默认的初始化栈的函数
    ############################
    def __init__(self):
        self.MaxStackSize=100
        self.s=[None for x in range(0,self.MaxStackSize)]
        self.top=-1
    ############################
    #判断栈是否为空的函数
    ############################    
    def IsEmptyStack(self):
        if self.top==-1:
              iTop=True
        else:
              iTop=False
        return   iTop
    ############################
    #元素进栈的函数
    ############################    
    def PushStack(self,x):
        if self.top<self.MaxStackSize-1:
            self.top=self.top+1
            self.s[self.top]=x
        else:
            print("栈满")
            return
    ############################
    #元素出栈的函数
    ############################        
    def PopStack(self):
        if self.IsEmptyStack():
            print("栈为空")
            return
        else:
            iTop=self.top
            self.top=self.top-1
            return self.s[iTop]
    #############################
    #依次访问栈中元素的函数
    #############################        
    def StackTraverse(self):
        if self.IsEmptyStack():
            print("栈为空")
            return
        else:
            for i in range(0,self.top+1):
                print(self.s[i],end='  ')
##############################################################
#类名称：TestPD
#类说明：定义一个测试回文单词的类
#类释义：判断是否为回文单词并测试判断是否正确
##############################################################
class  TestPD:
    #############################
    #判断是否为回文单词的函数
    #############################  
    def  Plalindrome(self,str):
                ss1=SequenceStack()
                ss2=SequenceStack()
                i=0
                while i<(len(str)):
                            ss1.PushStack(str[i])
                            i=i+1
                print("栈ss1内的元素依次为：",end='')
                ss1.StackTraverse()
                
                i=i-1 
                while i<(len(str))and i>=0:
                            ss2.PushStack(str[i])
                            i=i-1
                print("\n栈ss2内的元素依次为：",end='')
                ss2.StackTraverse()     
                tag=0
                while ss1.IsEmptyStack()!=True:
                    if ss1.PopStack()!=ss2.PopStack():
                        tag=1
                        print("\n当前栈ss1和ss2中的元素不相等，所以",str,"不是回文单词。")
                        return
                print("\n栈为空，说明栈ss1和ss2中的元素完全一致，所以",str,"是回文单词。")
    ###############################
    #测试回文单词函数的正确性的函数
    ###############################
    def  TestPlalindrome(self):
        str=input("请输入一个英文单词：")
        i=0
        while i<len(str):
            if (str[i]>='a'and str[i]<='z')or (str[i]>='A' and str[i]<='Z'):
                i=i+1
            else:
                break
        if i==len(str):
            self.Plalindrome(str)
        else:
            print("输入错误！")
#############################
#测试回文单词函数的正确性
#############################                                        
TPD=TestPD()
TPD.TestPlalindrome()
