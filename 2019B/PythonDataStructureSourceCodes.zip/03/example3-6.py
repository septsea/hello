##############################################################
#文件名：example3-6.py
#版本号：0.1
#创建时间：2017-09-15
#修改时间：2018-07-01
##############################################################
#类名称：CircularSequenceQueue
#类说明：定义一个循环队列
#类释义：提供循环顺序队列的相关操作
##############################################################
class CircularSequenceQueue:
    ############################
    #默认的初始化循环队列的函数
    ############################
    def __init__(self):
        self.MaxQueueSize=8
        self.s=[None for x in range(0,self.MaxQueueSize)]
        self.front=0
        self.rear=0
    #############################
    #判断循环队列是否为空的函数
    #############################
    def IsEmptyQueue(self):
        if self.front==self.rear:
             iQueue=True
        else:
             iQueue=False
        return iQueue
    #############################
    #元素入队的函数
    #############################
    def EnQueue(self,x):
          if (self.rear+1)%self.MaxQueueSize!=self.front:
              self.rear=(self.rear+1)%self.MaxQueueSize
              self.s[self.rear]=x
          else:
            print("队列已满，无法入队")
            return  
    #############################
    #元素出队的函数
    #############################        
    def DeQueue(self):
        if self.IsEmptyQueue():
           print("队列为空，无法出队")
           return
        else:
            self.front=(self.front+1)%self.MaxQueueSize
            return self.s[self.front]
    #############################
    #依次访问队列中元素的函数
    #############################        
    def QueueTraverse(self):
        if self.IsEmptyQueue():
            print("队列为空，队列无元素可以访问")
            return
        else:
            if  self.front<self.rear:
                i=self.front+1
                while i<self.rear:
                    print(self.s[i],end=' ')
                    i=i+1
                print(self.s[self.rear])
            else:
                i=self.front+1
                while i<self.MaxQueueSize:
                    print(self.s[i],end=' ')
                    i=i+1
                i=0
                while i<=self.rear:
                    print(self.s[i],end=' ')
                    i=i+1
    #############################
    #获取当前队首元素的函数
    #############################                
    def GetHead(self):
        if self.IsEmptyQueue():
            print("队列为空，无法输出队首元素")
            return
        else:
            return self.s[(self.front+1)%self.MaxQueueSize]
#############################
#男女混合比赛问题的函数
############################# 
class TestMAB:
      #############################
      #男女混合比赛问题的函数
      #############################      
      def MatchAB(self):
          quA=CircularSequenceQueue() 
          quB=CircularSequenceQueue()
          print("请输入选手的编号，男生：M****，女生：F****，并以-1结尾。")          
          while True:
            Num=input("请输入选手编号：")
            if Num=='-1':
                break
            else:
                if len(Num)==5:                  
                  if Num[0]=='M':
                      quA.EnQueue(Num)
                  elif Num[0]=='F':
                       quB.EnQueue(Num) 
                  else:
                      print("输入格式错误！")
                else:
                    print("输入格式错误！")
          print("A队列的元素有：",end='')
          quA.QueueTraverse()
          print()
          print("B队列的元素有：",end='')
          quB.QueueTraverse()
          print()
          print("组合的过程如下")  
          count=0  
          while True:
              if quA.IsEmptyQueue()and quB.IsEmptyQueue():
                 print("两队都为空，组合结束")
                 break
              elif quA.IsEmptyQueue():
                 print("A队为空，组合结束")
                 print("B队的剩余元素为：",end='')
                 quB.QueueTraverse()
                 break
              elif quB.IsEmptyQueue():
                 print("B队为空，组合结束")
                 print("A队的剩余元素为：",end='')
                 quA.QueueTraverse()
                 break
              else:
                 print(quA.DeQueue(),end='  ')
                 print("组合",end='  ')                
                 print(quB.DeQueue(),end='  ')
                 count=count+1
                 print() 
          print ("\n共有",count,"个组合")
#################################
#测试男女混合比赛问题函数的正确性
#################################                                       
TMAB=TestMAB()
TMAB.MatchAB()
      
    
        


            
