##############################################################
#文件名：example3-9.py
#版本号：0.1
#创建时间：2017-09-15
#修改时间：2018-07-01
#############################################################
#类名称：CPrint
#类说明：用于函数函数调用
#类释义：包含输出字符串的函数和输入字符串的函数
################################################
class CPrint:
    ############################
    #输出字符串的函数
    ############################     
    def PrintString(self,str):
        strPrintString="In PrintString(self,str):"
        print(strPrintString,str)
        return len(str)         
    #####################################
    #输入字符串并调用输出字符串函数的函数
    ##################################### 
    def InputString(self,strInputString):
        strInputString="In InputString(self,str):"+strInputString
        print("字符串",strInputString,"的长度为：",self.PrintString(strInputString))
        strInput=input("请输入您的姓名：")
        strInput="您的姓名为："+strInput
        self.PrintString(strInput)
if __name__ == '__main__':
    cp=CPrint()
    cp.InputString("This is main")
