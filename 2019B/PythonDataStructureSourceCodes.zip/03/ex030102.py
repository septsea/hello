#######################################################################
#文件名：ex030102.py
#版本号：0.1
#创建时间：2017-09-14
#修改时间：
#######################################################################
#类名称：SequenceStack
#类说明：定义一个栈
#类释义：提供顺序栈的相关操作
#######################################################################
class SequenceStack:
    ############################
    #默认的初始化栈的函数
    ############################
    def __init__(self):
        self.MaxStackSize=10
        self.s=[None for x in range(0,self.MaxStackSize)]
        self.top=-1
    ############################
    #判断栈是否为空的函数
    ############################    
    def IsEmptyStack(self):
        if self.top==-1:
              iTop=True
        else:
              iTop=False
        return   iTop
    ############################
    #元素进栈的函数
    ############################    
    def PushStack(self,x):
        if self.top<self.MaxStackSize-1:
            self.top=self.top+1
            self.s[self.top]=x
        else:
            print("栈满")
            return
    ############################
    #元素出栈的函数
    ############################        
    def PopStack(self):
        if self.IsEmptyStack():
            print("栈为空")
            return
        else:
            iTop=self.top
            self.top=self.top-1
            return self.s[iTop]
    #############################
    #依次访问栈中元素的函数
    #############################        
    def StackTraverse(self):
        if self.IsEmptyStack():
            print("栈为空")
            return
        else:
            for i in range(0,self.top+1):
                print(self.s[i],end='  ')
    ############################
    #获取当前栈顶元素的函数
    ############################                
    def GetTopStack(self):
        if self.IsEmptyStack():
            print("栈为空")
            return
        else:
            return self.s[self.top]
    ############################
    #输出当前栈长度的函数
    ############################   
    def GetStackLength(self):
        if self.IsEmptyStack():
            print("栈为空")
            return
        else:
            return self.top+1
    ###############################
    #由用户输入元素将其进栈的函数
    ###############################  
    def CreateStackByInput(self):
        data=input("请输入元素(继续输入请按回车，结束输入请按“#”：")
        while data!='#':
            self.PushStack(data)
            data=input("请输入元素：")
###############################
#测试CreateStackByInput()的程序
###############################
ss=SequenceStack()
ss.CreateStackByInput()
print("栈内的元素为：",end='')
ss.StackTraverse()
