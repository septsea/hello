###################################################
#文件名：example3-5.py
#版本号：0.1
#创建时间：2017-9-15
#修改时间：2018-07-01
####################################################
#类名称：QueueNode
#类说明：定义一个结点
#类释义：分别有数据元素data，指向下一个结点的指针next
#####################################################
class QueueNode:
    def __init__(self):
        self.data=None
        self.next=None
        self.length=0
class LinkQueue:
    ############################
    #默认的初始化队列的函数
    ############################
    def __init__(self):         
        tQueueNode=QueueNode()
        self.front=tQueueNode
        self.rear=tQueueNode
        self.length=0
    #############################
    #判断队列是否为空的函数
    #############################   
    def IsEmptyQueue(self):
        if self.front==self.rear:
            iQueue=True
        else:
            iQueue=False
        return  iQueue
    #############################
    #入队的函数
    #############################
    def EnQueue(self,data):
        tQueueNode=QueueNode()
        tQueueNode.data=data
        self.rear.next=tQueueNode
        self.rear=tQueueNode
        self.length=self.length+1
    #############################
    #出队的函数
    #############################    
    def DeQueue(self):
        if self.IsEmptyQueue():
            print("队列为空")
            return
        else:
            tQueueNode=self.front.next
            self.front.next=tQueueNode.next
            if self.rear==tQueueNode:
                self.rear=self.front
            self.length=self.length-1
            return tQueueNode.data
    ############################
    #获得当前队首元素的函数
    ############################  
    def GetHead(self):       
        if self.IsEmptyQueue():
            print("队列为空")
            return
        else:
            return self.front.next.data
    ############################
    #依次访问队列中元素的函数
    #############################
    def QueueTraverse(self):
        if self.IsEmptyQueue():
            print("队列为空")
            return
        else:
            tQueueNode=self.front.next
            while tQueueNode!=None:
                print(tQueueNode.data,end=' ')
                tQueueNode=tQueueNode.next
    ############################
    #获得当前队列长度的函数
    ############################
    def GetQueueLength(self):
        return self.length
##############################################################
#类名称：TestJP
#类说明：测试约瑟夫环问题
#类释义：包括约瑟夫环问题的实现以及测试。
############################################################## 
class TestJP:
    #############################
    #约瑟夫环问题的函数
    #############################  
    def Josephus(self,n,k):
        qu=LinkQueue()
        i=1
        while i<=n:
            qu.EnQueue(i)
            i=i+1
        print("队内的编号顺序为：",end='')   
        qu.QueueTraverse()
        print("\n出队顺序为：")
        count=0
        while qu.GetQueueLength()!=1:
            iNum=1
            while iNum!=k:
                tData=qu.DeQueue()
                qu.EnQueue(tData)
                iNum=iNum+1
            print(qu.DeQueue(),end='   ')
            count=count+1
            if count%10==0:
                print()
                print()  
        print("\n最后剩下的一个编号为：",end='')
        qu.QueueTraverse()
    ###################################
    #测试约瑟夫环问题函数的正确性的函数
    ###################################
    def  TestJosephus(self):
        PeopleNum=int(input('请输入总的人数：'))
        Gap=int(input('请输入要出列的编号：'))
        if PeopleNum>0 and Gap>0 and Gap<=PeopleNum:
            self.Josephus(PeopleNum,Gap)
        else:
            print('输入不符合要求!')
#############################
#测试约瑟夫环问题函数的正确性
#############################                                        
TJP=TestJP()
TJP.TestJosephus()

            







