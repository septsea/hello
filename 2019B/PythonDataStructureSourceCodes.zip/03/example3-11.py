#######################################################################
#文件名：example3-11.py
#版本号：0.1
#创建时间：2017-09-14
#修改时间：2018-07-01
#######################################################################
#类名称：SequenceStack
#类说明：定义一个栈
#类释义：提供顺序栈的相关操作
#######################################################################
class SequenceStack:
    ############################
    #默认的初始化栈的函数
    ############################
    def __init__(self):
        self.MaxStackSize=100
        self.s=[None for x in range(0,self.MaxStackSize)]
        self.top=-1
    ############################
    #初始化栈的函数
    ############################
    def InitStack(self):
        self.MaxStackSize=100
        self.s=[None for x in range(0,self.MaxStackSize)]
        self.top=-1
    ############################
    #判断栈是否为空的函数
    ############################    
    def IsEmptyStack(self):
        if self.top==-1:
              iTop=True
        else:
              iTop=False
        return   iTop
    ############################
    #元素进栈的函数
    ############################    
    def PushStack(self,x):
        if self.top<self.MaxStackSize-1:
            self.top=self.top+1
            self.s[self.top]=x
        else:
            print("栈满")
            return
    ############################
    #元素出栈的函数
    ############################        
    def PopStack(self):
        if self.IsEmptyStack():
            print("栈为空")
            return
        else:
            iTop=self.top
            self.top=self.top-1
            return self.s[iTop]
    ############################
    #获取当前栈顶元素的函数
    ############################                
    def GetTopStack(self):
        if self.IsEmptyStack():
            print("栈为空")
            return
        else:
            return self.s[self.top]
    ############################
    #输出当前栈长度的函数
    ############################   
    def GetStackLength(self):
        if self.IsEmptyStack():
            print("栈为空")
            return
        else:
            return self.top+1
#######################################################################
#类名称：HanoiElements
#类说明：定义汉诺塔函数的信息元素
#类释义：将汉诺塔函数的信息元素初始化
#######################################################################
class HanoiElements:
    #######################################
    #默认的初始化汉诺塔函数的信息元素的函数
    #######################################
    def __init__(self):
        self.Tag=0
        self.N=None
        self.A=None
        self.B=None
        self.C=None
#######################################################################
#类名称：TestFact
#类说明：定义汉诺塔非递归的实现
#类释义：提供汉诺塔非递归实现的函数
#######################################################################
class TestHanioTower:
    ###############################
    #初始化移动次数的函数
    ###############################    
    def __init__(self):
        self.count=0
    ###############################
    #将n号金片从NA移到NC的函数
    ###############################
    def move(self,NA,n,NC):
        self.count=self.count+1
        print("第",self.count,"次移动：将第",n,"号金片从",NA,"移到",NC)
    ################################
    #汉诺塔非递归实现的函数
    ################################
    def HanioTower(self,n,NA,NB,NC):
        HE=HanoiElements()
        HE.N=n
        HE.A=NA
        HE.B=NB
        HE.C=NC
        st=SequenceStack()
        st.PushStack(HE)
        while st.IsEmptyStack()!=True:
            while True:
                tHE=st.GetTopStack()
                if tHE.N>1 and tHE.Tag==0:
                    temp=HanoiElements()
                    temp.N=tHE.N-1
                    temp.A=tHE.A
                    temp.B=tHE.C
                    temp.C=tHE.B
                    st.PushStack(temp)
                elif tHE.N==1 and tHE.Tag==0:
                    self.move(tHE.A,tHE.N,tHE.C)
                    tHE.Tag=1
                    break
            while st.IsEmptyStack()!=True:
                tHE=st.GetTopStack()
                if tHE.Tag==1:
                    st.PopStack()
                else:
                    break
            if st.IsEmptyStack()==True:
                break
            temp=st.GetTopStack()
            self.move(temp.A,temp.N,temp.C)
            temp.Tag=1
            t=HanoiElements()
            t.N=temp.N-1
            t.A=temp.B
            t.B=temp.A
            t.C=temp.C
            st.PushStack(t)
#############################
#测试汉诺塔非递归函数的正确性
#############################
TH=TestHanioTower()
TH.HanioTower(3,'A','B','C')








        
