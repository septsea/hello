#######################################################################
#文件名：example3-2.py
#版本号：0.1
#创建时间：2017-09-14
#修改时间：2018-07-01
#######################################################################
##类名称：StackNode
#类说明：定义一个结点
#类释义：分别有数据元素data，指向下一个结点的指针next
#######################################################################
class StackNode:
   #############################
    #默认的初始化结点的函数
    #############################
    def __init__(self):
        self.data=None
        self.next=None
class LinkStack:
    #############################
    #默认的初始化链栈的函数
    #############################
    def __init__(self):
        self.top=StackNode()
    ###############################
    #初始化逆置栈元素的列表的函数
    ###############################
    def InitReverseStack(self):
        self.RSList=[]
    #############################
    #判断栈是否为空的函数
    #############################     
    def IsEmptyStack(self):        
        if self.top.next==None:
            iTop=True
        else:
            iTop=False
        return iTop
    #############################
    #进栈的函数
    #############################
    def PushStack(self,data):
        tStackNode=StackNode()
        tStackNode.data=data
        tStackNode.next=self.top.next
        self.top.next=tStackNode
    #############################
    #出栈的函数
    #############################    
    def PopStack(self):          
         if self.IsEmptyStack()==True:
             print("栈为空.")
             return
         else:
            tStackNode=self.top.next
            self.top.next=tStackNode.next
            return tStackNode.data
    #############################
    #获得当前栈顶元素的函数
    #############################   
    def GetTopStack(self):       
        if self.IsEmptyStack()==True:
            return
        else:
            return self.top.next.data
    #############################
    #依次访问链栈中元素的函数
    ############################# 
    def StackTraverse(self):
        tStackNode=self.top
        while tStackNode.next!=None:
            self.RSList.append(tStackNode.next.data)
            tStackNode=tStackNode.next
    ###############################
    #将栈内元素存入列表并逆置的函数
    ############################### 
    def ReverseStackTraverse(self):
        self.InitReverseStack()
        self.StackTraverse()
        for i in range(len(self.RSList)-1,-1,-1):
            print(self.RSList[i],end=' ')
##############################################################
#类名称：BracketMatch
#类说明：括号匹配
#类释义：读取源程序，判断其括号是否匹配
##############################################################        
class TestBM:
    ########################################
    #读取文件的内容的函数
    ########################################
    def ReadFile(self,strFileName):
        f=open(strFileName)
        str=f.read()
        f.close()
        print("要判断括号匹配的源程序如下：")
        print(str)
        return str                                 
################################
#检查括号是否匹配的函数
################################
    def BracketMatch(self,str):
        ls=LinkStack()
        i=0
        while i<len(str):
            if str[i]=='{':
                ls.PushStack(str[i])
                i=i+1
            elif str[i]=='}':
                if ls.GetTopStack()=='{':
                    ls.PopStack()
                    i=i+1
                else:
                     ls.PushStack(str[i])
                     i=i+1
            else:
                i=i+1
        if ls.IsEmptyStack()==True:
            print("括号匹配成功!")        
        else:
            print("括号匹配不成功!")
            print("未匹配的括号为：",end='')
            ls.ReverseStackTraverse()
#############################
#测试括号匹配函数的正确性
#############################                                        
TBM=TestBM()
TBM.BracketMatch(TBM.ReadFile("example3-2.c"))
            
    
    
