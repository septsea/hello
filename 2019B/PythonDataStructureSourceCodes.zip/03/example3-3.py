#######################################################################
#文件名：example3-3.py
#版本号：0.1
#创建时间：2017-09-14
#修改时间：2018-07-01
#######################################################################
#类名称：SequenceStack
#类说明：定义一个栈
#类释义：提供顺序栈的相关操作
#######################################################################
class SequenceStack:
    ############################
    #默认的初始化栈的函数
    ############################
    def __init__(self):
        self.MaxStackSize=100
        self.s=[None for x in range(0,self.MaxStackSize)]
        self.top=-1
    #############################
    #判断栈是否为空的函数
    #############################    
    def IsEmptyStack(self):
        if self.top==-1:
            iTop=True
        else:
            iTop=False
        return  iTop  
    #############################
    #进栈的函数
    #############################    
    def PushStack(self,x):
        if self.top<self.MaxStackSize-1:
            self.top=self.top+1
            self.s[self.top]=x
        else:
            print("栈满")
            return
    #############################
    #出栈的函数
    #############################        
    def PopStack(self):
        if self.top==-1:
            print("栈为空.")
            return
        else:
            i=self.top
            self.top=self.top-1
            return self.s[i]
class TestMaze:
    ############################################
    #当前位置到达相邻位置所需移动的坐标
    ############################################
    Directions=[(0,1),(1,0),(0,-1),(-1,0)]
    ############################################
    #判断当前位置是否可以通行的函数
    ############################################
    def IsPossiblePass(self,mazeroute,position):
        if mazeroute[position[0]][position[1]]==0:
            route=True
        else:
            route=False
        return route
    #################################################
    #将走过的位置置为2的函数
    #################################################
    def PassedMark(self,mazeroute,position):
        mazeroute[position[0]][position[1]]=2
    #################################
    #走出迷宫后打印走过的路径的函数
    #################################
    def PrintRoute(self,Exit,st):
        print("从出口到入口的路径为：")
        print(Exit,end= ' ')
        i=1
        while st.IsEmptyStack()!=True:
            print(st.PopStack()[0],end=' ')
            i=i+1
            if i%10==0:
                print()
    #####################################
    #寻找迷宫路径的函数
    #####################################
    def FindMazeRoute(self,mazeroute,Enter,Exit):
        st=SequenceStack()        
        position=Enter
        nxt=0
        while True:
            if position==Exit:
                self.PrintRoute(Exit,st)
                return
            else:
                self.PassedMark(mazeroute,position)
                for i in range(nxt,4):
                    nextposition=(position[0]+self.Directions[i][0],
                                  position[1]+self.Directions[i][1])
                    if self.IsPossiblePass(mazeroute,nextposition):
                        st.PushStack((position,i+1))
                        position=nextposition
                        nxt=0
                        break
                else:
                    if st.IsEmptyStack():
                        break
                    else:
                        position,nxt=st.PopStack()
        print("没有找到通过迷宫的路径")
#############################
#测试寻找迷宫路径函数的正确性
#############################
TM=TestMaze()
mazeroute=[[1,1,1,1,1,1,0,1,1,1],
           [1,0,0,0,0,1,0,1,1,1],
           [1,0,1,1,0,1,0,0,0,1],
           [1,0,1,1,0,1,1,1,0,1],
           [1,0,1,1,0,0,0,0,0,1],
           [1,0,1,1,0,1,1,1,1,1],
           [1,0,1,1,0,0,0,0,0,1],
           [1,0,1,1,1,1,1,1,1,1],
           [1,0,0,0,0,0,0,0,0,0],
           [1,1,1,1,1,1,1,1,1,1]]
TM.FindMazeRoute(mazeroute,(0,6),(8,9))
