#######################################################################
#文件名：example3-10.py
#版本号：0.1
#创建时间：2017-09-14
#修改时间：2018-07-01
#######################################################################
#类名称：SequenceStack
#类说明：定义一个栈
#类释义：提供顺序栈的相关操作
#######################################################################
class SequenceStack:
    ############################
    #默认的初始化栈的函数
    ############################
    def __init__(self):
        self.MaxStackSize=100
        self.s=[None for x in range(0,self.MaxStackSize)]
        self.top=-1
    ############################
    #初始化栈的函数
    ############################
    def InitStack(self):
        self.MaxStackSize=100
        self.s=[None for x in range(0,self.MaxStackSize)]
        self.top=-1
    ############################
    #判断栈是否为空的函数
    ############################    
    def IsEmptyStack(self):
        if self.top==-1:
              iTop=True
        else:
              iTop=False
        return   iTop
    ############################
    #元素进栈的函数
    ############################    
    def PushStack(self,x):
        if self.top<self.MaxStackSize-1:
            self.top=self.top+1
            self.s[self.top]=x
        else:
            print("栈满")
            return
    ############################
    #元素出栈的函数
    ############################        
    def PopStack(self):
        if self.IsEmptyStack():
            print("栈为空")
            return
        else:
            iTop=self.top
            self.top=self.top-1
            return self.s[iTop]
    ############################
    #获取当前栈顶元素的函数
    ############################                
    def GetTopStack(self):
        if self.IsEmptyStack():
            print("栈为空")
            return
        else:
            return self.s[self.top]
#######################################################################
#类名称：FactElements
#类说明：定义阶乘函数的信息元素
#类释义：提供阶乘函数的信息元素的初始化
#######################################################################
class FactElements:
    #####################################
    #默认的初始化阶乘函数的信息元素的函数
    #####################################
   def __init__(self):
      self.LabelN=None
      self.N=None
      self.F=None
#######################################################################
#类名称：TestFact
#类说明：定义阶乘非递归算法的实现
#类释义：提供阶乘非递归算法的函数
#######################################################################
class TestFact:
    #########################
    #阶乘非递归算法的函数
    #########################
   def Factorial(self,n):
       FE=FactElements()
       FE.LabelN=2
       FE.N=n
       st=SequenceStack()
       st.PushStack(FE)
       while True:
           tFE=st.GetTopStack()
           if tFE.N>=1:
               temp=FactElements()
               temp.LabelN=1
               temp.N=tFE.N-1
               st.PushStack(temp)
           else:
               tFE.F=1
               break
       while True:
           tFE=st.GetTopStack()
           if tFE.LabelN==1:
               st.PopStack()
               temp=st.GetTopStack()
               temp.F=tFE.F*temp.N
           tFE=st.GetTopStack()
           if tFE.LabelN==2:
               tFE=st.PopStack()
               f=tFE.F
               break       
       print(tFE.N,"的阶乘为",f)
#########################
#测试程序
#########################
TF=TestFact()
TF.Factorial(6)
      
