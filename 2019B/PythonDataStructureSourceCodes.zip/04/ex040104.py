##################################################
#文件名：ex040104.py
#版本号：0.1
#创建时间：2017-09-14
#修改时间：2018-07-01
##################################################
#类名称：StringList
#类说明：定义一个顺序串
#类释义：提供顺序串的某些操作以及BF算法和KMP算法
##################################################
class StringList:
    ############################
    #默认的初始化串的函数
    ############################
    def __init__(self):
         self.MaxStringSize=256
         self.chars=""
         self.length=0
    ############################
    #判断串是否为空的函数
    ############################    
    def IsEmptyString(self):
        if self.length==0:
            IsEmpty=True
        else:
            IsEmpty=False
        return IsEmpty
    ############################
    #创建串的函数
    ############################
    def CreateStringList(self):
        string=input("请输入字符串,按回车结束输入：")
        if  len(string)>self.MaxStringSize:            
            print("输入的字符串的超过分配的内存，超过的部分无法存入。")
            self.chars=string[:self.MaxStringSize]
            self.length=self.MaxStringSize
        else:
            self.chars=string[:]
            self.length=len(self.chars)
    ############################
    #输出一个串的字符序列函数
    ############################
    def StringTraverse(self):
        print(self.chars)
    ############################
    #获取串长度的函数
    ############################   
    def GetStringLength(self):
        return self.length
    ############################
    #获取串字符序列的函数
    ############################   
    def GetString(self):
        return self.chars    
    ############################
    #BF算法
    ############################
    def IndexBF(self,pos,T):
        count=0    #用于统计匹配次数
        length=T.GetStringLength()
        if len(self.chars)<length:
            print("模式串的长度大于主串的长度，无法进行字符串的模式匹配。")
        else:
            i=pos
            string=T.GetString()
            while (i<=len(self.chars)-length):
                iT=i
                j=0
                tag=False
                while j<length:
                    if self.chars[i]==string[j]:
                        i=i+1
                        j=j+1
                    else:
                        break
                if j==length:
                    print("匹配成功! 模式串在主串中首次出现的位置为",iT)
                    tag=True
                    break
                else:
                    i=iT+1
                    count=count+1
            if tag==False:
                print("匹配失败！")
            print("使用BF算法共进行了",count+1,"次匹配")
    ############################
    #获取模式串ListNext值的函数
    ############################
    def GetListNext(self):                
        ListNext=[None for x in range(0,100)]
        ListNext[0]=-1
        k=-1
        j=0
        while j<len(self.chars): 
            if k==-1 or self.chars[j]==self.chars[k]:
                k=k+1
                j=j+1
                ListNext[j]=k
            else: 
                k=ListNext[k]
        return ListNext
    ################################
    #获取模式串ListNextValue值的函数
    ################################
    def GetListNextValue(self):                
        ListNextValue=[None for x in range(0,100)]
        ListNextValue[0]=-1
        k=-1
        j=0
        while j<len(self.chars)-1: 
            if k==-1 or self.chars[j]==self.chars[k]:
                k=k+1
                j=j+1
                if self.chars[j]!=self.chars[k]:
                    ListNextValue[j]=k
                else:
                    ListNextValue[j]=ListNextValue[k]
            else: 
                k=ListNextValue[k]
        return ListNextValue
    ################################
    #KMP算法
    ################################
    def IndexKMP(self,pos,T,ListNext_ListNextValue):
        i=pos
        j=0
        count=0       #用于统计匹配次数
        length=T.GetStringLength()
        string=T.GetString()
        while i<len(self.chars)and j<length:
            if j==-1 or self.chars[i]==string[j]:
                i=i+1
                j=j+1
            else:
                j=ListNext_ListNextValue[j]
                count=count+1
        if j==length:
            print("匹配成功! 模式串在主串中首次出现的位置为",i-length)
        else:
            print("匹配失败！")
        print("共进行了",count+1,"次匹配")
######################################################
#类名称：TestIndex
#类说明：定义一个测试模式匹配算法的类
#类释义：测试BF算法和KMP算法
######################################################
class TestIndex:
    #################################
    #测试BF算法的正确性
    #################################
    def TestIndexBF(self):
        S=StringList()
        S.CreateStringList()
        print("主串为：",end='')
        S.StringTraverse()
        T=StringList()
        T.CreateStringList()
        print("模式串为：",end='')
        T.StringTraverse()
        pos=int(input("请输入从主串的哪一位置开始串的模式匹配："))
        print("匹配结果：",end='')
        S.IndexBF(pos,T)
    ##################################
    #测试KMP算法正确性
    ##################################
    def TestIndexKMP(self):
        S=StringList()
        S.CreateStringList()
        print("主串为：",end='')
        S.StringTraverse()
        print()
        T=StringList()
        T.CreateStringList()
        print("模式串为：",end='')
        T.StringTraverse()
        pos=int(input("\n请输入从主串的哪一位置开始串的模式匹配："))
        print("\n借助ListNext值的匹配结果：",end='')
        S.IndexKMP(pos,T,T.GetListNext())
        print("\n借助ListNextValue值的匹配结果：",end='')
        S.IndexKMP(pos,T,T.GetListNextValue())
##############################
#测试TestIndexBF()函数的正确性
##############################
#TI=TestIndex()
############################################################
#算法4-13 测试TestIndexBF()函数的正确性
############################################################
#TI.TestIndexBF()

############################################################
#算法4-18 测试TestIndexKMP()函数的正确性
############################################################
#TI.TestIndexKMP()
                 
