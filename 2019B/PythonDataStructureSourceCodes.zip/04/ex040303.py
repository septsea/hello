##################################################
#文件名：ex040303.py
#版本号：0.1
#创建时间：2017-09-14
#修改时间：2018-07-01
##################################################
import copy
######################################################
#类名称：GLNode
#类说明：定义广义表的一个结点
#类释义：包含标志域、联合域（当标志域为1时，此域是指向
#        当前表的子表的指针，为0时代表原子结点的值、指
#        向下一结点的指针域
######################################################
class GLNode(object):
    ##################################
    #默认的初始化广义表结点的构造函数
    ##################################
    def __init__(self):
        self.tag=None
        self.union=None
        self.next=None
######################################################
#类名称：GList
#类说明：定义广义表
#类释义：包含广义表的相关操作
######################################################
class GList(object):
    ########################################
    #创建广义表的函数
    ########################################
    def CreateGList(self,Table):
        if len(Table)>0:
            tTable=Table.pop(0)
            tGLNode=GLNode()
            if tTable=='(':
                tGLNode.tag=1
                tGLNode.union=self.CreateGList(Table)
            elif tTable==')'or tTable=='#':
                tGLNode=None
            else:
                tGLNode.tag=0
                tGLNode.union=tTable
        else:
            tGLNode=None
        if len(Table)>0:
            tTable=Table.pop(0)
        if  tGLNode!=None:
            if tTable==',':
                tGLNode.next=self.CreateGList(Table)
            else:
                tGLNode.next=None
        return tGLNode
    ##################################
    #遍历广义表的函数
    ##################################
    def TraverseGList(self,GList):
        if GList!=None:
            if GList.tag==0:
                print(GList.union,end='')
            else:
                print('(',end='')
                if GList.union==None:
                    print('#',end='')
                else:
                    self.TraverseGList(GList.union)
                print(')',end='')
            if GList.next!=None:
                print(',',end='')
                self.TraverseGList(GList.next)
    ##############################
    #获取广义表表头的函数
    ##############################
    def GetGListHead(self,GList):
        if GList!=None and GList.union!=None:
            head=copy.deepcopy(GList.union)
            head.next=None
            return head
        else:
            print("无法获取表头！")        
    ##############################
    #获取广义表表尾的函数
    ##############################
    def GetGListTail(self,GList):
        if GList!=None and GList.union!=None:
            tail=copy.deepcopy(GList.union.next)
            return tail
        else:
            print("表尾为空表！")
########################################################
#类名称：TextGList
#类说明：测试广义表的相关实现
#类释义：包含输入广义表书写形式串的方法、测试广义表的方法
#########################################################
class TextGList(object):
    def Input(self):
        print("请输入广义表的书写形式串:",end='')
        element=input()
        Table=[]
        for item in element:
            Table.append(item)
        return Table
    def TextGL(self):
        gl=GList()
        GL=gl.CreateGList(self.Input())
        print("创建的广义表为：",end='')
        gl.TraverseGList(GL)
        print("\n广义表的表头元素为：",end='')
        head=gl.GetGListHead(GL)
        gl.TraverseGList(head)
        print("\n广义表的表尾为：",end='')
        print("(",end='')
        tail=gl.GetGListTail(GL)
        gl.TraverseGList(tail)
        print(")")
##############################
#主程序
##############################
TGL=TextGList()
TGL.TextGL()

