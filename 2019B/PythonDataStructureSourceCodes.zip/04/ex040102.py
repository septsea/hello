######################################################
#文件名：ex040102.py
#版本号：0.1
#创建时间：2017-09-14
#修改时间：2018-07-01
######################################################
#类名称：StringList
#类说明：定义一个顺序串
#类释义：提供顺序串的相关操作
######################################################
class StringList:
    ############################
    #默认的初始化串的函数
    ############################
    def __init__(self):
         self.MaxStringSize=256
         self.chars=""
         self.length=0
    ############################
    #判断串是否为空的函数
    ############################    
    def IsEmptyString(self):
        if self.length==0:
            IsEmpty=True
        else:
            IsEmpty=False
        return IsEmpty
    ############################
    #创建一个串的函数
    ############################
    def CreateString(self):
        stringSH=input("请输入字符串,请按回车结束输入：")
        if  len(stringSH)>self.MaxStringSize:            
            print("输入的字符序列超过分配的存储空间，超过的部分无法存入当前串中。")
            self.chars=stringSH[:self.MaxStringSize]
        else:
            self.chars=stringSH
    ############################
    #输出一个串的函数
    ############################
    def StringTraverse(self):
        print(self.chars)
    ############################
    #串连接的函数
    ############################
    def StringConcat(self,strSrc):
        lengthSrc=strSrc.length
        stringSrc=strSrc.chars
        if lengthSrc+len(self.chars)<=self.MaxStringSize:
            self.chars=self.chars+stringSrc
        else:
            print("两个字符串连接后的长度超过分配的内存，超过的部分无法显示。")
            size=self.MaxStringSize-len(self.chars)
            self.chars=self.chars+stringSrc[0:size]
        print("连接后的字符串为：",self.chars)
    #####################################
    #从指定位置开始获取指定长度子串的函数
    #####################################
    def SubString(self,iPos,length):
        if iPos>len(self.chars)or iPos<0 or length<1 or(length>len(self.chars)-iPos):
            print("无法获取子串。")
        else:
            substr=self.chars[iPos:iPos+length]
            print("获取的字串为：",substr)  
			
######################################################
#以下为测试代码
######################################################	
#创建目标字符串	
###############	
#stringDst=StringList()
#stringDst.CreateString()
#print("目的串为：",end='')
#stringDst.StringTraverse()

###############	
#创建源字符串	
###############	
#stringSrc=StringList()
#stringSrc.CreateString()
#print("源串为：",end='')
#stringSrc.StringTraverse()

###############	
#连接字符串	
###############	
##stringDst.StringConcat(stringSrc)

###############	
#截取字符串	
###############	
#从第0个位置开始进行各项操作
##position=int(input("请输入要从第几个位置截取："))
##length=int(input("请输入要截取的长度："))
##stringDst.SubString(position,length)
 
