######################################################
#文件名：ex040103.py
#版本号：0.1
#创建时间：2017-09-14
#修改时间：2018-07-01
######################################################
#类名称：StringNode
#类说明：定义一个结点
#类释义：包含数据域data和指针域next
######################################################
class StringNode:
    ############################
    #默认的初始化串结点的函数
    ############################
      def __init__(self):
           self.data=None
           self.next=None
######################################################
#类名称：StringLink
#类说明：定义一个链串
#类释义：提供链串的相关操作
######################################################
class StringLink:
    ############################
    #默认的初始化串的函数
    ############################
    def __init__(self):
         self.head=StringNode()
         self.tail=self.head
         self.length=0
    ############################
    #判断串是否为空的函数
    ############################    
    def IsEmptyString(self):
        if self.head.next==None:
            IsEmpty=True
        else:
            IsEmpty=False
        return IsEmpty
    ############################
    #遍历链串的函数
    ############################
    def StringTraverse(self):
        if self.IsEmptyString():
            print("链串为空。")
        else:
            Tstring=self.head.next
            while Tstring!=None:
                print(Tstring.data,end='')
                Tstring=Tstring.next
    ############################
    #创建一个链式串的函数
    ############################
    def CreateString(self):
        stringSH=input("\n请输入字符串,请按回车结束输入：")
        while self.length<len(stringSH):
            Tstring=StringNode()
            Tstring.data=stringSH[self.length]
            self.tail.next=Tstring
            self.tail=Tstring
            self.length=self.length+1
    ############################
    #复制链串的函数
    ############################
    def StringCopy(self,strSrc):
        self.head=strSrc.head
        self.tail=strSrc.tail
        self.length=strSrc.length   
    ############################
    #链串联接的函数
    ############################
    def StringConcat(self,strSrc):
        self.tail.next=strSrc.head.next
        self.tail=strSrc.tail
        self.length=self.length+strSrc.length
######################################################
#以下为测试代码
######################################################	
#创建目标字符串	
###############			  
#stringDst=StringLink()
#stringDst.CreateString()
#print("stringDst为：",end='')
#stringDst.StringTraverse()

################	
#创建源字符串	
###############	
#stringSrc=StringLink()
#stringSrc.CreateString()
#print("stringSrc为：",end='')
#stringSrc.StringTraverse()

################	
#复制字符串	
###############	
##stringDst.StringCopy(stringSrc)
##print("\nstringDst复制stringSrc后的串为：",end='')
##stringDst.StringTraverse()

################	
#连接字符串	
###############	
##stringDst.StringConcat(stringSrc)
##print("\n连接的结果为：",end='')
##stringDst.StringTraverse()
