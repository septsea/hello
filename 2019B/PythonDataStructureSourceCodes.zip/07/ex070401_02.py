#################################################################
# 文件名：ex070401_02.py
# 版本号：0.1
# 创建时间：2017-09-14
# 修改时间：
#################################################################
# 类名称：Element
# 类说明：数据元素类型
# 类释义：该类拥有带排序的关键字key
#################################################################
class Element(object):
    def __init__(self, key):
        self.key = key
        self.next=None
#################################################################
# 类名称：HashTable
# 类说明：静态查找表的顺序存储结构
# 类释义：该类拥有一个数据元素类型的列表data和data的长度length
#################################################################
class HashTable(object):   
    def __init__(self):
        self.data=[]
        self.length=0        
    ########################
    # 创建数据元素类型列表
    ########################
    def CreateHashTableLinked(self,elements):
        addr=None
        print("现有关键字的数目为：",len(elements))
        self.length=int(input("请输入哈希表的长度："))
        temp=self.length
        while temp%2 is 0:
            temp=temp-1
        for i in range(self.length):
            self.data.append(Element(None))
        for i in range(len(elements)):
            addr=elements[i]%temp
            if self.data[addr].next is None:
                self.data[addr].next=Element(elements[i])
            else:
               p=self.data[addr].next
               while p.next is None:
                    self.data[addr].next.next=Element(elements[i])
                    break
    #######################################
    # 算法7-10 基于拉链法解决冲突的查找算法
    #######################################
    def SearchHashTableLinked(self,key):
        iPos=-1
        addr=key%self.length
        if self.data[addr] is None:
            return iPos 
        elif self.data[addr].key is key:
             iPos=addr
             return iPos
        elif self.data[addr].key is  not key:
            p=self.data[addr]
            while p.next is not None:
                if p.next.key is key:
                    iPos=addr
                    return iPos
                else:
                    p=p.next
            return iPos
    ###############################
    # 打印哈希表
    ###############################
    def PrintHashTable(self):
        for i  in range(len(self.data)):
            p=self.data[i]
            while p.next is not None:
                print(i,"--->",p.next.key)
                p=p.next
                
            if self.data[i].next is None:
                print(i,"--->","   ")
HTdata = [16,74,60,43,54,90,46,31,29]
HT = HashTable()
HT.CreateHashTableLinked(HTdata)
HT.PrintHashTable()
while True:
    iKey = input("请输入待查找关键字(#退出):")
    if(iKey == '#'):
        break
    HTKey = int(iKey)
    i=HT.SearchHashTableLinked(HTKey)
    if i is -1:
        print("未找到关键字",HTKey)
    elif i is not -1:
        print("找到关键字",HTKey,"其位置为：",i)
