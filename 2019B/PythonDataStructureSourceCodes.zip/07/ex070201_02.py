#################################################################
# 文件名：ex070201_02.py
# 版本号：0.1
# 创建时间：2017-09-14
# 修改时间：
#################################################################
# 类名称：SElemType
# 类说明：数据元素类型
# 类释义：该类拥有带排序的关键字key
#################################################################
class StaticTableElement(object):
    def __init__(self, key):
        self.key = key
#################################################################
# 类名称：SSTable
# 类说明：静态查找表的顺序存储结构
# 类释义：该类拥有一个数据元素类型的列表data和data的长度length
#################################################################
class StaticTable(object):   
    def __init__(self):
        self.data=[]
        self.length=0        
    ########################
    # 创建数据元素类型列表
    
    ########################
    def CreateSequenceTable(self,elements):
        self.length=len(elements)
        for i in range(self.length):
            self.data.insert(i,StaticTableElement(elements[i]))            
    ########################
    # 打印待排序列表集合
    ########################
    def TraverseSequenceTable(self):
        print("待排序列表为：")
        for i in range(1,self.length):
            print(self.data[i].key, end="\t")
        print()
    ###################################################
    #算法7-2 改进的顺序查找(顺序查找函数加入“哨兵”)
    ###################################################
    def SequenceSearch1(self,key):
        self.data[0].key=key
        iPos=-1
        for i in range(self.length-1,0,-1):
            if self.data[i].key == key:
                iPos=i
                break
        return iPos
########################
# 主程序
########################
STdata = [None,1, 5, 8, 123, 22, 54, 7, 99, 300, 222]
ST = StaticTable()
ST.CreateSequenceTable(STdata)
ST.TraverseSequenceTable()
while True:
    iKey = input("请输入待查找关键字(#退出):")
    if(iKey == '#'):
        break
    STKey = int(iKey)
    STPos = ST.SequenceSearch1(STKey)
    if STPos is -1:
        print("在静态查找表中未找到关键字",STKey)
    else:
        print("关键字",STKey,"在静态查找表中的位置为：",STPos)

