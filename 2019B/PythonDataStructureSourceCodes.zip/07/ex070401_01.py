#################################################################
# 文件名：ex070401_01.py
# 版本号：0.1
# 创建时间：2017-09-14
# 修改时间：
#################################################################
#################################################################
# 类名称：Element
# 类说明：数据元素类型
# 类释义：该类拥有带排序的关键字key
#################################################################
class Element(object):
    def __init__(self, key):
        self.key = key
#################################################################
# 类名称：HashTable
# 类说明：静态查找表的顺序存储结构
# 类释义：该类拥有一个数据元素类型的列表data和data的长度length
#################################################################
class HashTable(object):   
    def __init__(self):
        self.data=[]
        self.length=0        
    ########################
    # 创建哈希表
    ########################
    def CreateHashTableList(self,elements):
        addr=None
        print("现有关键字的数目为：",len(elements))
        self.length=int(input("请输入哈希表的长度："))
        for i in range(self.length):
            self.data.append(None)
        for i in range(len(elements)):
            addr=elements[i]%self.length
            if self.data[addr] is None:
                self.data[addr]=Element(elements[i])
            else:
                while self.data[addr] is not None:
                    addr=(addr+1)%self.length
                self.data[addr]=Element(elements[i])
    ##########################################
    # 算法7-9 基于线性探测法解决冲突的查找算法
    ##########################################
    def SearchHashTableList(self,key):
        iPos=-1
        addr=key%self.length
        temp=addr
        if self.data[addr] is None:
            return iPos 
        elif self.data[addr].key is key:
             iPos=addr
             return iPos
        elif self.data[addr].key is  not key:
            while addr <= self.length-1:
                if self.data[addr] is None:
                    return iPos
                elif self.data[addr].key is  not key :
                    addr=(addr+1)%self.length
                elif self.data[addr].key is key:
                    iPos=addr
                    return iPos
            while True:
                i=0
                if self.data[i] is None:
                    return iPos
                elif self.data[i].key is  not key :
                    addr=(i+1)%self.length
                elif self.data[i].key is key:
                    iPos=addr
                    return iPos
    ########################
    # 打印哈希表函数
    ########################
    def PrintHashTable(self):
        for i  in range(len(self.data)):
            if self.data[i]:
                print(i,"--->",self.data[i].key)
            else:
                print(i,"--->","   ")
HTdata = [16,74,60,43,54,90,46,31,29,88,77,12]
HT = HashTable()
HT.CreateHashTableList(HTdata)
HT.PrintHashTable()
while True:
    iKey = input("请输入待查找关键字(#退出):")
    if(iKey == '#'):
        break
    HTKey = int(iKey)
    i=HT.SearchHashTableList(HTKey)
    if i is -1:
        print("未找到关键字",HTKey)
    elif i is not -1:
        print("找到关键字",HTKey,"其位置为：",i)
