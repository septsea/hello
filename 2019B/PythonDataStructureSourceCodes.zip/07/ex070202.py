#################################################################
# 文件名：ex070202.py
# 版本号：0.1
# 创建时间：2017-09-14
# 修改时间：
#################################################################
# 类名称：SElemType
# 类说明：数据元素类型
# 类释义：该类拥有带排序的关键字key
#################################################################
class StaticTableElement(object):
    def __init__(self, key):
        self.key = key
#################################################################
# 类名称：SSTable
# 类说明：静态查找表的顺序存储结构
# 类释义：该类拥有一个数据元素类型的列表data和data的长度length
#################################################################
class StaticTable(object):   
    def __init__(self):
        self.data=[]
        self.length=0        
    ########################
    # 创建数据元素类型列表
    ########################
    def CreateSequenceTable(self,elements):
        self.length=len(elements)
        for i in range(self.length):
            self.data.append(StaticTableElement(elements[i]))            
    ########################
    # 打印待排序列表集合
    ########################
    def TraverseSequenceTable(self):
        print("待排序列表为：")
        for i in range(self.length):
            print(self.data[i].key, end="\t")
        print()
    ########################
    # 算法7-3 折半查找函数
    ########################
    def BinarySearch(self, key):
        low = 0
        high = self.length - 1
        while low <= high:
            mid = int((low + high) / 2)
            if key is self.data[mid].key:
                return mid
            elif key < self.data[mid].key:
                high = mid - 1
            elif key > self.data[mid].key:
                low = mid + 1
        return False
########################
# 主程序
########################
STdata= [3,8,10,12,15,18,20,25,30,36,48,67,89,120]
STdata.sort()
ST = StaticTable()
ST.CreateSequenceTable(STdata)
ST.TraverseSequenceTable()
while True:
    iKey = input("请输入待查找关键字(#退出):")
    if(iKey == '#'):
        break
    STKey = int(iKey)
    STPos = ST.BinarySearch(STKey)
    if STPos is False:
        print("在静态查找表中未找到关键字",STKey)
    else:
        print("关键字",STKey,"在静态查找表中的位置为：",STPos)

