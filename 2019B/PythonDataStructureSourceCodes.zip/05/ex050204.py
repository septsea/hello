#################################################################
#文件名：ex050204(5.2.4 线索二叉树 算法5-13~算法5-16)
#版本号：0.3
#创建时间：2017-11-8
#修改时间：2017-11-22
#################################################################
#类名称：BinaryTreeNodeThread
#类说明：定义一个二叉树的结点
#类释义：二叉树中的每一个结点包含左孩子LeftChild，右孩子RightChild
#        ,数据data,左标志LTag和右标志RTag
#################################################################
#算法5-13 线索化二叉树的结点定义
#################################################################
class BinaryTreeNodeThread(object):
    def __init__(self):
        self.data = '#'
        self.LeftChild  = None
        self.RightChild = None
        self.LTag = 0
        self.RTag = 0
#########################################################################
#类名称：BinaryTree
#类说明：定义一个二叉树
#类释义：包括创建二叉树、对二叉树线索化、中序遍历线索二叉树等基本操作
#########################################################################
class BinaryTree(BinaryTreeNodeThread):    
    ##############################
    #初始化该树,创建该树的头结点
    ##############################
    def __init__(self):
        self.HeadNode = BinaryTreeNodeThread()
        self.HeadNode.LTag = 0
        self.HeadNode.RTag = 1
        self.HeadNode.RightChild = self.HeadNode
    ########################
    #创建二叉树的函数
    ########################
    def CreateBinaryTree(self, BinaryTree):
        data = input('->')
        if data == '#':
            BinaryTree = None
        else:
            BinaryTree.data = data
            BinaryTree.LeftChild = BinaryTreeNodeThread()
            self.CreateBinaryTree(BinaryTree.LeftChild)
            BinaryTree.RightChild = BinaryTreeNodeThread()
            self.CreateBinaryTree(BinaryTree.RightChild)
    ##########################################
    #算法5-16 遍历中序线索二叉树的算法
    ##########################################
    def InOrderClue(self):
        BinaryTreeNode = self.HeadNode.LeftChild
        while BinaryTreeNode is not self.HeadNode:
            while BinaryTreeNode.LTag ==0:
                BinaryTreeNode = BinaryTreeNode.LeftChild
            self.VisitBinaryTreeNode(BinaryTreeNode)
            while BinaryTreeNode.RTag == 1 and BinaryTreeNode.RightChild is not self.HeadNode:
                BinaryTreeNode = BinaryTreeNode.RightChild
                self.VisitBinaryTreeNode(BinaryTreeNode)
            BinaryTreeNode = BinaryTreeNode.RightChild
    ########################
    #访问线索二叉树一个结点
    ########################
    def VisitBinaryTreeNode(self,BinaryTreeNode):
        #值为#的结点代表空结点
        if BinaryTreeNode.data is not '#':
            print(BinaryTreeNode.data)
            #print (str(BinaryTreeNode.data)+str(BinaryTreeNode.LTag)+'~'+str(BinaryTreeNode.RTag)+'\t',end="")
    forward = None
    ####################################
    #算法5-14 建立中序线索二叉树的函数
	####################################
    def InOrderThreading(self,Root):
        if Root is None:
            self.HeadNode.LeftChild = self.HeadNode
        else:
            self.HeadNode.LeftChild = Root
            self.forward = self.HeadNode
            self.InThreading(Root)
            self.forward.RTag = 1
            self.forward.RightChild = self.HeadNode
            self.HeadNode.RightChild = self.forward
    ################################
    #算法5-15 中序线索化二叉树的函数
    ################################
    def InThreading(self,BinaryTreeNode):
        if BinaryTreeNode is not None:
            self.InThreading(BinaryTreeNode.LeftChild)
            if BinaryTreeNode.LeftChild is None:
                BinaryTreeNode.LTag = 1
                BinaryTreeNode.LeftChild = self.forward
            if self.forward.RightChild is None:
                self.forward.RTag = 1
                self.forward.RightChild = BinaryTreeNode
            self.forward = BinaryTreeNode
            self.InThreading(BinaryTreeNode.RightChild)
########################
#主程序
########################
#bTN是根结点
bTN = BinaryTreeNode()
bT = BinaryTree()
print ('创建一棵二叉树\n')
print ('         4')
print ('        / \\')
print ('       5   6')
print ('      / \\  \\')
print ('     1   2  7 ')
print ('4 5 1 # # 2 # # 6 # 7 # #')
#创建一棵二叉树并线索化
print('请仿照上述序列，输入某一二叉树中各结点的值（#表示空结点），每输入一个值按回车换行：')
bT.CreateBinaryTree(bTN)
print('线索化二叉树！')
bT.InOrderThreading(bTN)
print('遍历中序线索二叉树!')
bT.InOrderClue()
