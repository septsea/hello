#####################################################################################################
#文件名：ex050402~03(5.4.2 哈夫曼算法及实现 算法5-22~5-24 5.4.3 哈夫曼编码及应用 算法5-25~算法5-27)
#版本号：0.5
#创建时间：2017-11-29
#修改时间：2017-12-4
#####################################################################################################
#####################################################################
#类名称：HuffmanTreeNode
#类说明：算法5-22 哈夫曼树的结点
#类释义：分别有左孩子LeftChild，右孩子RightChild，数据data和权weight
#####################################################################
class HuffmanTreeNode(object):
    def __init__(self):
        self.data = '#'
        self.weight = -1
        self.parent = None
        self.LeftChild  = None
        self.RightChild = None
#################################################################
#类名称：HuffmanTree
#类说明：定义一棵哈夫曼树
#################################################################
class HuffmanTree(object):
    ###############################
    #算法5-23 构造哈夫曼树的函数
    ###############################
    def CreateHuffmanTree(self,Nodes):
        TreeNode=Nodes[:]
        if len(TreeNode)>0:
            while len(TreeNode)>1:
                LeftTreeNode = TreeNode.pop(0)
                RightTreeNode = TreeNode.pop(0)
                NewNode = HuffmanTreeNode()
                NewNode.LeftChild = LeftTreeNode
                NewNode.RightChild = RightTreeNode
                NewNode.weight = LeftTreeNode.weight + RightTreeNode.weight
                LeftTreeNode.parent = NewNode
                RightTreeNode.parent = NewNode
                self.InsertTreeNode(TreeNode,NewNode)
            return TreeNode[0]
    #################################################
    #算法5-24 将某一结点插入列表中
    #################################################
    def InsertTreeNode(self,TreeNode,NewNode):
        if len(TreeNode)>0:
            tmp=0
            while tmp<len(TreeNode):
                if TreeNode[tmp].weight > NewNode.weight:
                    TreeNode.insert(tmp,NewNode)
                    return
                tmp = tmp+1
        TreeNode.append(NewNode)
    ##########################
    #算法5-25 哈夫曼编码函数
    ##########################
    def HuffmanEncoding(self,Root,Nodes,Codes):
        index = range(len(Nodes))
        for item in index:
            tmp = Nodes[item]
            tCode = ''
            while tmp is not Root:
                if tmp.parent.LeftChild is tmp:
                    tCode = '0' + tCode
                else:
                    tCode = '1' + tCode
                tmp = tmp.parent
            Codes.append(tCode)
	#####################################
    #算法5-26 创建所有叶子结点的函数
    #####################################
    def CreateLeafNodes(self,LeafNodes):
        print('请按照叶子结点权值的升序，分组输入叶子结点的值和权值，如A 10,并以# #结束。')
        NodeInformation = input('->').split(' ')
        while NodeInformation[1] is not '#':
            NewNode = HuffmanTreeNode()
            NewNode.data = NodeInformation[0]
            NewNode.weight = int(NodeInformation[1])
            LeafNodes.append(NewNode)
            NodeInformation = input('->').split() 
            

##########################################
#使用列表LeafNodes存储所有叶子结点
##########################################
LeafNodes=[]
#############################################
#根据给定的八种字符及其出现的频率创建叶子结点
#############################################
huffman = HuffmanTree()
huffman.CreateLeafNodes(LeafNodes)
###################################################
#由叶子结点创建哈夫曼树，root存储哈夫曼树的根结点
###################################################
print('创建哈夫曼树！')
root = huffman.CreateHuffmanTree(LeafNodes)
###################################################
#依次求LeafNodes中叶子结点的哈夫曼编码并存入Codes
###################################################
Codes=[]
print('求所有字符的哈夫曼编码！')
huffman.HuffmanEncoding(root,LeafNodes,Codes)
###########################
#输出叶子结点的哈夫曼编码
###########################
print('各字符的哈夫曼编码如下：')
for index in range(len(Codes)):
    print(LeafNodes[index].data+':'+Codes[index])

