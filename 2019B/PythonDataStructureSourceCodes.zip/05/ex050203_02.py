#################################################################
#文件名：ex050203_01(算法5-12 层次遍历算法)
#版本号：0.1
#创建时间：2017-11-17
#修改时间：
##############################################################
#类名称：CircularSequenceQueue
#类说明：定义一个循环队列
#类释义：提供循环顺序队列的相关操作
##############################################################
class CircularSequenceQueue:
    ############################
    #默认的初始化循环队列的函数
    ############################
    def __init__(self):
        self.MaxQueueSize=4
        self.s=[None for x in range(0,self.MaxQueueSize)]
        self.front=0
        self.rear=0
    ############################
    #初始化循环队列的函数
    ############################
    def InitQueue(self,Max):
        self.MaxQueueSize=Max
        self.s=[None for x in range(0,self.MaxQueueSize)]
        self.front=0
        self.rear=0
    #############################
    #判断循环队列是否为空的函数
    #############################
    def IsEmptyQueue(self):
        if self.front==self.rear:
             iQueue=True
        else:
             iQueue=False
        return iQueue
    #############################
    #元素入队的函数
    #############################
    def EnQueue(self,x):
          if (self.rear+1)%self.MaxQueueSize!=self.front:
              self.rear=(self.rear+1)%self.MaxQueueSize
              self.s[self.rear]=x
          else:
            print("队列已满，无法入队")
            return  
    #############################
    #元素出队的函数
    #############################        
    def DeQueue(self):
        if self.IsEmptyQueue():
           print("队列为空，无法出队")
           return
        else:
            self.front=(self.front+1)%self.MaxQueueSize
            return self.s[self.front]
#################################################################
#类名称：BinaryTreeNode
#类说明：定义一个二叉树的结点
#类释义：分别有左孩子LeftChild，右孩子RightChild和数据data
#################################################################
class BinaryTreeNode(object):
    def __init__(self):
        self.data = '#'
        self.LeftChild  = None
        self.RightChild = None
 
#########################################################################
#类说明：定义一个二叉树
#类释义：定义一个类，用于对二叉树进行层次遍历
#########################################################################
class BinaryTree(object):
    ########################
    #创建二叉树的函数
    ########################
    def CreateBinaryTree(self, Root):
        data = input('->')
        if data == '#':
            Root = None
        else:
            Root.data = data
            Root.LeftChild = BinaryTreeNode()
            self.CreateBinaryTree(Root.LeftChild)
            Root.RightChild = BinaryTreeNode()
            self.CreateBinaryTree(Root.RightChild)
    ###########################
    #层次遍历二叉树的函数
    ###########################
    def LevelOrder(self,Root):
        tSequenceQueue = CircularSequenceQueue()
        tSequenceQueue.InitQueue(100)
        tSequenceQueue.EnQueue(Root)
        tTreeNode = None
        while tSequenceQueue.IsEmptyQueue() == False:
            tTreeNode = tSequenceQueue.DeQueue()
            self.VisitBinaryTreeNode(tTreeNode)
            if tTreeNode.LeftChild is not None:
                tSequenceQueue.EnQueue(tTreeNode.LeftChild)
            if tTreeNode.RightChild is not None:
                tSequenceQueue.EnQueue(tTreeNode.RightChild)
    ############################
    #遍历二叉树的一个结点函数
    ############################
    def VisitBinaryTreeNode(self, BinaryTreeNode):
        #值为#的结点代表空结点
        if BinaryTreeNode.data is not '#':
            print (BinaryTreeNode.data)
            
        
########################
#主程序
########################
bTN = BinaryTreeNode()
bT = BinaryTree()
print ('创建一棵二叉树\n')
print ('         4')
print ('        / \\')
print ('       5   6')
print ('      / \\  \\')
print ('     1   2  7 ')
print ('4 5 1 # # 2 # # 6 # 7 # #')
#创建一棵二叉树
print('请仿照上述序列，输入某一二叉树中各结点的值（#表示空结点），每输入一个值按回车换行：')
bT.CreateBinaryTree(bTN)
print ('对二叉树进行层次遍历:')
#层次遍历二叉树
bT.LevelOrder(bTN)
