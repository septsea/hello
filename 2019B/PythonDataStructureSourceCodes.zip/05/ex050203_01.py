#################################################################
#文件名：ex050203_01(5.2.3 二叉树的遍历 算法5-6~算法5-11)
#版本号：0.5
#创建时间：2017-09-13
#修改时间：2017-11-20
#################################################################
#类名称：BinaryTreeNode
#类说明：定义一个二叉树的结点
#类释义：分别有左孩子LeftChild，右孩子RightChild和数据data
#################################################################
class BinaryTreeNode(object):
    def __init__(self):
        self.data = '#'
        self.LeftChild  = None
        self.RightChild = None
class TreeState(object):
    def __init__(self,BinaryTreeNode,VisitedFlag):
        self.BinaryTreeNode = BinaryTreeNode
        self.VisitedFlag = VisitedFlag
#########################################################################
#类说明：定义一个二叉树
#类释义：定义一个类，用于对二叉树进行一些操作，主要操作有：创建二叉树、
#        先序遍历二叉树、中序遍历二叉树、后序遍历二叉树，其中的遍历操作
#        都是递归的
#########################################################################
class BinaryTree(object):
    ########################
    #创建二叉树的函数
    ########################
    def CreateBinaryTree(self, Root):
        data = input('->')
        if data == '#':
            Root = None
        else:
            Root.data = data
            Root.LeftChild = BinaryTreeNode()
            self.CreateBinaryTree(Root.LeftChild)
            Root.RightChild = BinaryTreeNode()
            self.CreateBinaryTree(Root.RightChild)
    ###########################
    #算法5-6 先序遍历递归算法
    ###########################
    def PreOrder(self, Root):
        if Root is not None:
            self.VisitBinaryTreeNode(Root)
            self.PreOrder(Root.LeftChild)
            self.PreOrder(Root.RightChild)
    ###########################
    #算法5-8 中序遍历递归算法
    ###########################
    def InOrder(self, Root):
        if Root is not None:
            self.InOrder(Root.LeftChild)
            self.VisitBinaryTreeNode(Root)
            self.InOrder(Root.RightChild)
    ###########################
    #算法5-10 后序遍历递归算法
    ###########################
    def PostOrder(self, Root):
        if Root is not None:
            self.PostOrder(Root.LeftChild)
            self.PostOrder(Root.RightChild)
            self.VisitBinaryTreeNode(Root)
    ########################
    #遍历二叉树一个结点函数
    ########################
    def VisitBinaryTreeNode(self, BinaryTreeNode):
        #值为#的结点代表空结点
        if BinaryTreeNode.data is not '#':
            print (BinaryTreeNode.data)



#########################################################################
#类说明：定义一个二叉树
#类释义：定义一个类，用于对二叉树进行一些操作，主要操作有：创建二叉树、
#        先序遍历二叉树、中序遍历二叉树、后序遍历二叉树，其中的遍历操作
#        都是非递归的
#########################################################################
class BinaryTreeNonRecursive(BinaryTreeNode):
    ########################
    #创建二叉树的函数
    ########################
    def CreateBinaryTree(self, Root):
        data = input('->')
        if data == '#':
            Root = None
        else:
            Root.data = data
            Root.LeftChild = BinaryTreeNode()
            self.CreateBinaryTree(Root.LeftChild)
            Root.RightChild = BinaryTreeNode()
            self.CreateBinaryTree(Root.RightChild)
    #############################
    #算法5-7 先序遍历非递归算法
    #############################
    def PreOrderNonRecursive(self, Root):
        StackTreeNode = []
        tTreeNode = Root
        while len(StackTreeNode)>0 or tTreeNode is not None:
            while tTreeNode is not None:
                self.VisitBinaryTreeNode(tTreeNode)
                StackTreeNode.append(tTreeNode)
                tTreeNode = tTreeNode.LeftChild
            if len(StackTreeNode)>0:
                tTreeNode = StackTreeNode.pop()
                tTreeNode = tTreeNode.RightChild
    
    #############################
    #算法5-9 中序遍历非递归算法
    #############################
    def InOrderNonRecursive(self, Root):
        StackTreeNode = []
        tTreeNode = Root
        while len(StackTreeNode)>0 or tTreeNode is not None:
            while tTreeNode is not None:
                StackTreeNode.append(tTreeNode)
                tTreeNode = tTreeNode.LeftChild
            if len(StackTreeNode)>0:
                tTreeNode = StackTreeNode.pop()
                self.VisitBinaryTreeNode(tTreeNode)
                tTreeNode = tTreeNode.RightChild
    
    ################################
    #算法5-11 后序遍历的非递归算法
    ################################
    def PostOrderNonRecursive(self,Root):
        StackTreeNode = []
        tBinaryTreeNode = Root
        tTree = None
        while tBinaryTreeNode is not None:
            tTree = TreeState(tBinaryTreeNode,0)
            StackTreeNode.append(tTree)
            tBinaryTreeNode = tBinaryTreeNode.LeftChild
        while len(StackTreeNode)>0:
            tTree = StackTreeNode.pop()
            if tTree.BinaryTreeNode.RightChild is None or tTree.VisitedFlag == 1:
                self.VisitBinaryTreeNode(tTree.BinaryTreeNode)
            else:
                StackTreeNode.append(tTree)
                tTree.VisitedFlag = 1
                tBinaryTreeNode=tTree.BinaryTreeNode.RightChild
                while tBinaryTreeNode is not None:
                    tTree = TreeState(tBinaryTreeNode,0)
                    StackTreeNode.append(tTree)
                    tBinaryTreeNode = tBinaryTreeNode.LeftChild
    ############################
    #遍历二叉树的一个结点函数
    ############################
    def VisitBinaryTreeNode(self, BinaryTreeNode):
        #值为#的结点代表空结点
        if BinaryTreeNode.data is not '#':
            print (BinaryTreeNode.data)

########################
#主程序
########################
bTN = BinaryTreeNode()
bT = BinaryTree()
print ('创建一棵二叉树\n')
print ('         4')
print ('        / \\')
print ('       5   6')
print ('      / \\  \\')
print ('     1   2  7 ')
print ('4 5 1 # # 2 # # 6 # 7 # #')
#创建一棵二叉树
print('请仿照上述序列，输入某一二叉树中各结点的值（#表示空结点），每输入一个值按回车换行：')
bT.CreateBinaryTree(bTN)
print ('对二叉树进行前序遍历:\n')
#前序遍历二叉树
bT.PreOrder(bTN)
print ('对二叉树进行中序遍历:\n')
#中序遍历二叉树
bT.InOrder(bTN)
print ('对二叉树进行后序遍历:\n')
#后序遍历二叉树
bT.PostOrder(bTN)


###################################
#非递归遍历二叉树
###################################
btnrn = BinaryTreeNode()
btrn = BinaryTreeNonRecursive()
#创建一棵二叉树
print('请仿照上述序列，输入某一二叉树中各结点的值（#表示空结点），每输入一个值按回车换行：')
btrn.CreateBinaryTree(btnrn)
print ('对二叉树进行非递归前序遍历:\n')
#前序遍历二叉树
btrn.PreOrderNonRecursive(btnrn)
print ('对二叉树进行非递归中序遍历:\n')
#中序遍历二叉树
btrn.InOrderNonRecursive(btnrn)
print ('对二叉树进行非递归后序遍历:\n')
#后序遍历二叉树
btrn.PostOrderNonRecursive(btnrn)

