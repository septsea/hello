#################################################################
#文件名：ex050205(5.2.5 二叉树的典型应用 算法5-17~算法5-21)
#版本号：0.5
#创建时间：2017-11-8
#修改时间：2017-11-9
#################################################################
###############################################################
#中缀表达式转换成后缀表达式
#类名称：InfixExpression
#类说明：定义一个类，用于队后缀表达式进行一些操作，主要操作是
#将一个中缀表达式转换为一个后缀表达式
###############################################################
class InfixExpression(object):
    def __init__(self,expression):
        self.InfixExpression = expression.split(' ')
        self.PostfixExpression = []
    ####################################################
    #算法5-17 将中缀表达式转换为后缀表达式的算法
    ####################################################
    def InfixToPostfix(self):
        operator = []
        for item in self.InfixExpression:
            if item in ['+', '-', '*', '/']:
                while len(operator) >= 0:
                    if len(operator) == 0:
                        operator.append(item)
                        break
                    tmp = operator.pop()
                    if tmp == '(' or self.Grade(item) > self.Grade(tmp):
                        operator.append(tmp)
                        operator.append(item)
                        break
                    else:
                        self.PostfixExpression.append(tmp)
            elif item == '(':
                operator.append(item)
            elif item == ')':
                while len(operator) > 0:
                    tmp = operator.pop()
                    if tmp != '(':
                        self.PostfixExpression.append(tmp)
                    else:
                        break
            else:
                self.PostfixExpression.append(item)
        while len(operator) > 0:
            self.PostfixExpression.append(operator.pop())
    ############################
    #返回运算符的运算级的函数
    ############################
    def Grade(self,operator):
        if operator == '+':
            return 1
        elif operator == '-':
            return 1
        elif operator == '*':
            return 2
        else:
            return 2
#################################################################
#类名称：LinkedBinaryTreeNode
#类说明：定义一个二叉树的结点
#类释义：分别有左孩子LeftChild，右孩子RightChild和数据data
#################################################################
class LinkedBinaryTreeNode(object):
    def __init__(self):
        self.data = '#'
        self.LeftChild  = None
        self.RightChild = None
#################################################################
#类说明：定义一个二叉树
#类释义：根据一个后缀表达式建立一棵二叉树
#################################################################
class BinaryTree(BinaryTreeNode):
    def __init__(self,PostfixExpression):
        self.PostfixExpression = PostfixExpression
    ######################################
    #算法5-18 由后缀表达式创建二叉树的函数
    ######################################
    def CreatePostfixBinaryTree(self, Root):
        StackTreeNode = []
        for item in self.PostfixExpression:
            if item in ['+', '-', '*', '/']:
                OperandTwo = StackTreeNode.pop()
                OperandOne = StackTreeNode.pop()
                RootNode = LinkedBinaryTreeNode()
                RootNode.data = item
                RootNode.LeftChild = OperandOne
                RootNode.RightChild = OperandTwo
                StackTreeNode.append(RootNode)
            else:
                TreeNode = LinkedBinaryTreeNode()
                TreeNode.data = item
                StackTreeNode.append(TreeNode)
        TreeNode = StackTreeNode.pop()
        Root.data = TreeNode.data
        Root.LeftChild = TreeNode.LeftChild
        Root.RightChild = TreeNode.RightChild
        print('创建二叉树成功！')
    #####################################################
    #算法5-19 先序遍历二叉树获取前缀表达式的算法
    #####################################################
    def GetPrefixExpression(self, BinaryTree,expression):
        if BinaryTree is not None:
            self.GetPrefixExpression(BinaryTree.LeftChild,expression)#注意此处与教材不一致,以此处为准
            self.GetPrefixExpression(BinaryTree.RightChild,expression)#注意此处与教材不一致,以此处为准
            self.VisitBinaryTree(BinaryTree,expression)
    ###############################		
    #先序遍历二叉树，得到前缀表达式
    ###############################
    def PreOrder(self, BinaryTree,expression):
        if BinaryTree is not None:
            self.VisitBinaryTree(BinaryTree,expression)
            self.PreOrder(BinaryTree.LeftChild,expression)
            self.PreOrder(BinaryTree.RightChild,expression)
    ########################
    #访问二叉树的一个结点
    ########################
    def VisitBinaryTree(self, BinaryTree,expression):
        print (str(BinaryTree.data)+' ',end="")
        expression = expression.append(BinaryTree.data)

#################################################################
#类名称：PostfixExpression
#类说明：定义一个类用于对后缀表达式求值
#################################################################
class PostfixExpression(object):
    def __init__(self):
        self.result = ''
    ##################################
    #算法5-20  前缀表达式求值的算法
    ##################################
    def GetValue(self,PostfixExpression):
        StackValue = []
        for item in PostfixExpression:
            if item in ['+', '-', '*', '/']:
                operand2 = StackValue.pop()
                operand1 = StackValue.pop()
                result = self.Calculation(operand1, operand2, item)
                StackValue.append(result)
            else:
                StackValue.append(int(item))
        self.result = str(StackValue[0])
    ########################
    #进行四则运算的函数
    ########################
    def Calculation(self,operand1, operand2, operator):
        if operator == '+':
            return operand1 + operand2
        if operator == '-':
            return operand1 - operand2
        if operator == '*':
            return operand1 * operand2
        if operator == '/':
            return operand1 / operand2
#################################################################
#类名称：PrefixExpression
#类说明：定义一个类用于对前缀表达式求值
#################################################################
class PrefixExpression(object):
    def __init__(self):
        self.result = None
    ########################
    #前缀表达式求值的函数
    ########################
    def GetValue(self,expression):
        StackValue = []
        index = len(expression)-1
        while index >=0:
            if expression[index] in ['+', '-', '*', '/']:
                OperandOne = StackValue.pop()
                OperandTwo = StackValue.pop()
                result = self.Calculation(OperandOne,OperandTwo,expression[index])
                if result is 'error':
                    print('除数不能为0.')
                    return
                StackValue.append(result)
            else:
                StackValue.append(int(expression[index]))
            index = index -1
        result = StackValue.pop()
        self.result = result
    ########################
    #进行四则运算的函数
    ########################
    def Calculation(self,OperandOne, OperandTwo, operator):
        if operator == '+':
            return OperandOne + OperandTwo
        elif operator == '-':
            return OperandOne - OperandTwo
        elif operator == '*':
            return OperandOne * OperandTwo
        elif operator == '/':
            if OperandTwo == 0:
                return 'error'
            else:
                return OperandOne / OperandTwo
    def __init__(self,InfixExpression):
        self.InfixExpression = InfixExpression
    ######################################
    #由中缀表达式创建二叉树的函数
    ######################################
    def CreateBinaryTree(self, Root):
        StackOperator = []
        StackTreeNode = []
        for item in self.InfixExpression:
            if item in ['+', '-', '*', '/']:
                if len(StackOperator) >0 and item in ['+','-']:
                    Operand2 = StackTreeNode.pop()
                    Operand1 = StackTreeNode.pop()
                    RootNode = LinkedBinaryTreeNode()
                    RootNode.data = StackOperator.pop()
                    RootNode.LeftChild = Operand1
                    RootNode.RightChild = Operand2
                    StackTreeNode.append(RootNode)
                    StackOperator.append(item)
                else:
                    StackOperator.append(item)
            else:
                TreeNode = BinaryTreeNode()
                TreeNode.data = item
                StackTreeNode.append(TreeNode)
        while len(StackOperator) >0:
            RootNode = BinaryTreeNode()
            RootNode.data = StackOperator.pop()
            RootNode.RightChild = StackTreeNode.pop()
            RootNode.LeftChild = StackTreeNode.pop()
            StackTreeNode.append(RootNode)
        Root.data = StackTreeNode[0].data
        Root.LeftChild = StackTreeNode[0].LeftChild
        Root.RightChild = StackTreeNode[0].RightChild
    ###############################
    #后序遍历二叉树，得到后缀表达式
    ###############################
    def PostOrder(self, BinaryTree,expression):
        if BinaryTree is not None:
            self.PostOrder(BinaryTree.LeftChild,expression)
            self.PostOrder(BinaryTree.RightChild,expression)
            self.VisitBinaryTree(BinaryTree,expression)
    ###############################		
    #先序遍历二叉树，得到前缀表达式
    ###############################
    def PreOrder(self, BinaryTree,expression):
        if BinaryTree is not None:
            self.VisitBinaryTree(BinaryTree,expression)
            self.PreOrder(BinaryTree.LeftChild,expression)
            self.PreOrder(BinaryTree.RightChild,expression)
    ########################
    #访问二叉树一个结点
    ########################
    def VisitBinaryTree(self, BinaryTree,expression):
        print (str(BinaryTree.data)+' ',end="")
        expression = expression.append(str(BinaryTree.data))


################################
#算法5-21  计算中缀表达式的值
################################
expression = '9 + ( 3 - 1 ) * 3 + 10 / 2'
print('题目所给中缀表达式为：')
print(expression)
###################################
#(1)将中缀表达式转换为后缀表达式
###################################
iexpression = InfixExpression(expression)
iexpression.InfixToPostfix()
print('转换之后的后缀表达式为：')
print(' '.join(iexpression.PostfixExpression))
##################################################
#(2)根据后缀表达式创建一棵二叉树，root是树的根结点
##################################################
print('由后缀表达式创建二叉树！')
bt = BinaryTree(iexpression.PostfixExpression)
root = LinkedBinaryTreeNode()
bt.CreateBinaryTree(root)
################################################################
#(3)前序遍历二叉树得到前缀表达式，expression存储得到的前缀表达式
################################################################
expression = []
print('前序遍历二叉树得到的前缀表达式如下：')
bt.PreOrder(root,expression)
#################################
#(4)计算并输出前缀表达式的结果
#################################
pexpression = PrefixExpression()
pexpression.GetValue(expression)
print('\n'+'运算结果：'+str(pexpression.result))

