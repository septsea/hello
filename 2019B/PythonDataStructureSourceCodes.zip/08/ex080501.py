﻿import copy
#################################################################
# 文件名：ex080501.py
# 版本号：0.1
# 创建时间：2017-09-14
# 修改时间：
#################################################################
class Item(object):
    def __init__(self ,key,value):
        self.key = key
        self.value = value
class SortSequenceList(object):
    def __init__(self):
        self.SeqList=[]


    def  CreateSequenceListByInput(self):
        print("请输入一组待排序的数，每输入一个数据按回车换行：")
        data=input('->')
        while data != '#':
            self.SeqList.append(Item(int(data), None))
            data=input('->')

    def  CreateSequenceListByList(self,SequenceList):
        for item in SequenceList:
            self.SeqList.append(Item(int(item), None))

    def TraverseElementSet(self):
        for item in self.SeqList:
            print(item.key)
            
    ###################
    #算法8-14 一次归并
    ###################
    def Merge(self,TR1,i,m,n):
        TR2=[]
        for item in TR1:
            TR2.append(item)
        j=m+1
        k=i
        while i<=m and j<=n:
            if TR1[i].key<=TR1[j].key:
                TR2[k]=TR1[i]
                i=i+1
            else:
                TR2[k]=TR1[j]
                j=j+1
            k=k+1
        while i<=m:
            TR2[k]=TR1[i]
            i=i+1
            k=k+1
        while j<=n:
            TR2[k]=TR1[j]
            j=j+1
            k=k+1
        index=0       
        while index<len(TR1):
            TR1[index]=TR2[index]
            index=index+1
	####################
	#算法8-15 归并排序
	####################
    def MergeSort(self,TR1,s,t):
        if s==t:
            TR1[s]=self.SeqList[s]
        else:
            m=(s+t)//2
            self.MergeSort(TR1,s,m)
            self.MergeSort(TR1,m+1,t)
            self.Merge(TR1,s,m,t)
            index=s
            while index<=t:
                self.SeqList[index]=copy.deepcopy(TR1[index])
                index=index+1

if __name__ =='__main__':
    sl=SortSequenceList()   
    sl.CreateSequenceListByInput()
    length=len(sl.SeqList)
    TR1=[Item(0,None) for i in range(length)]
    sl.MergeSort(TR1,0,length-1)    
    sl.TraverseElementSet()
