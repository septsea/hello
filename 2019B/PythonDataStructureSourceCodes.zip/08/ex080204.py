﻿#################################################################
# 文件名：ex080203.py
# 版本号：0.1
# 创建时间：2017-09-14
# 修改时间：
#################################################################
#算法8-5 初始化结点
###################
class LinkListItem(object):
    def __init__(self, key=None, value=0, link=-1):
        self.key = key
        self.value = value
        self.link = link


class SortLinkList(object):
    def __init__(self):
        self.LinkList = []

    def CreateLinkListByInput(self, nElement):
        self.LinkList.append(LinkListItem())
        print("请输入数据：")
        for i in range(1, nElement + 1):
            a = input()
            self.LinkList.append(LinkListItem(int(a), i))
   
    def TraverseElementSet(self):
        Lnk = self.LinkList[0].next
        while self.LinkList[Lnk].key != None:
            print(self.LinkList[Lnk].key)
            Lnk = self.LinkList[Lnk].next
            
    #############################
    #算法8-6 表插入排序算法
    ############################# 
    def TableInsertSort(self):
        self.LinkList[0].next=1
        self.LinkList[1].next=0
        LinkListLen=len(self.LinkList)
        for i in range(2,LinkListLen):
            q=self.LinkList[0].next  
            p=0
            while q!=0 and self.LinkList[i].key>=self.LinkList[q].key:
                p=q
                q=self.LinkList[q].next
            self.LinkList[i].next=q
            self.LinkList[p].next=i



if __name__ == '__main__':
    SL = SortLinkList()
    SL.CreateLinkListByInput(10)
    SL.TableInsertSort()
    print('表插入排序算法结果为:')
    SL.TraverseElementSet()
 
