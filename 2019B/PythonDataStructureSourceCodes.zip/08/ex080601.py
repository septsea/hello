﻿#################################################################
# 文件名：ex080601.py
# 版本号：0.1
# 创建时间：2017-09-14
# 修改时间：
#################################################################
#算法8-16 初始化结点
####################
class LinkNode(object):
    def __init__(self,number):
        self.data=[0 for i in range(3)]
        self.data[0]=(number%100)%10
        self.data[1]=(number%100)//10
        self.data[2]=number//100
        self.next=None
class SortLinkList(object):
    def __init__(self):
        self.LinkList=None

    def CreateSortLinkList(self):
        print('请输入一组数字（0~999），并用回车键间隔：')
        data=input('->')
        while data != '#':
            if self.LinkList is None:
                self.LinkList=LinkNode(int(data))
                tNode=self.LinkList
            else:
                node=LinkNode(int(data))
                tNode.next=node
                tNode=node
            data=input('->')
            
    def TraverseElementSet(self):
        head=self.LinkList
        while head is not None:
            result=head.data[0]+head.data[1]*10+head.data[2]*100
            print(result)
            head=head.next
            
    #########################################
    #算法8-17 一趟分配 
    #########################################            
    def Distribute(self,head,tail,r,i):
        j=0
        while j<r:
            head[j]=tail[j]=None
            j=j+1
        while self.LinkList is not None:
            k=self.LinkList.data[i]
            if head[k] is None:
                head[k]=self.LinkList
                tail[k]=self.LinkList
            else:
                tail[k].next=self.LinkList
                tail[k]=self.LinkList
            self.LinkList=self.LinkList.next
	#################### 
	#算法8-18 一趟收集
	#################### 
    def Collect(self,r,head,tail):
        t=None
        FirstNumber=None
        j=0
        while j<r:
            if head[j] is not None:
                if FirstNumber is None:
                    FirstNumber=head[j]
                    t=tail[j]
                else:
                    t.next=head[j]
                    t=tail[j]
            j=j+1
        t.next=None
        self.LinkList=FirstNumber
	######################### 
	#算法8-19 链式基数排序
	#########################
    def RadixSort(self,r,d):       
        head=[0 for i in range(10)]       
        tail=[0 for i in range(10)]
        i=0
        if self.LinkList is not None:
            while i<=d-1:            
                self.Distribute(head,tail,r,i)           
                self.Collect(r,head,tail)
                i=i+1

if __name__ =='__main__':
    SL=SortLinkList()
    SL.CreateSortLinkList()
    SL.RadixSort(10,3)  
    SL.TraverseElementSet()
