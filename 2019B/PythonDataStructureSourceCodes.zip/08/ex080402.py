﻿#################################################################
# 文件名：ex080402.py
# 版本号：0.1
# 创建时间：2017-09-14
# 修改时间：
#################################################################
class ListItem(object):
    def __init__(self ,key,value):
        self.key = key
        self.value = value
class SortSequenceList(object):
    def __init__(self):
        self.SeqList=[]
    def  CreateSequenceListByInput(self,nElement):
        self.SeqList.append(ListItem(int(0), 0))
        print("请输入数据：")
        for i in range(1,nElement+1):
            a = input()
            self.SeqList.append(ListItem(int(a), i))
    def TraverseElementSet(self):
        for i in range(1,len(self.SeqList)):
            print(self.SeqList[i].key)


    ########################################
    #算法8-12 堆排序算法之调整剩余记录
    ########################################
    def AdjustHeap(self,i,SeqListLen):
        self.SeqList[0].key = self.SeqList[i].key       
        j=2*i
        while j <= SeqListLen :
            if j<SeqListLen and self.SeqList[j].key < self.SeqList[j+1].key :
                j=j+1
            if self.SeqList[0].key >= self.SeqList[j].key :break
            else:
                self.SeqList[i].key = self.SeqList[j].key
                i = j
                j = 2*j
        self.SeqList[i].key = self.SeqList[0].key
	#######################
    # 算法8-13 堆排序算法
	#######################
    def HeapSort(self):
        SeqListLen = len(self.SeqList)
        for i in range (SeqListLen//2,0,-1):
            self.AdjustHeap(i,SeqListLen-1)
        for j in range (SeqListLen-1,1,-1):
            self.SeqList[0].key = self.SeqList[1].key
            self.SeqList[1].key = self.SeqList[j].key
            self.SeqList[j].key = self.SeqList[0].key
            self.AdjustHeap(1,j-1)
      


if __name__ =='__main__':
    SL=SortSequenceList()
    SL.CreateSequenceListByInput(6)
    SL.HeapSort()
    print('排序算法结果为:')
    SL.TraverseElementSet()
 
